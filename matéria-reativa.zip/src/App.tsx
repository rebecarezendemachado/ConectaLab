import React, { useState } from 'react';
import './materia-reativa.css';
import { Logo } from './components/Logo';
import { LoginScreen } from './screens/LoginScreen';
import { CadastroScreen } from './screens/CadastroScreen';
import { EsqueceuSenhaScreen } from './screens/EsqueceuSenhaScreen';
import { DashboardScreen } from './screens/DashboardScreen';
import {
  FileCode,
  Code,
  Layers,
  Check,
  Copy,
  FolderTree,
  Monitor,
  ExternalLink,
  ChevronRight
} from 'lucide-react';

export type ScreenType = 'index' | 'login' | 'cadastro' | 'esqueceu-senha' | 'dashboard';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('index');
  const [dashboardMenu, setDashboardMenu] = useState<string>('Dashboard');
  const [userProfile, setUserProfile] = useState<'aluno' | 'professor'>('aluno');
  const [modalCodigo, setModalCodigo] = useState<'arquivos' | null>(null);
  const [copiado, setCopiado] = useState(false);

  // Sincronização com hash da URL para testes e atalhos diretos
  React.useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      if (hash === 'alertas') {
        setCurrentScreen('dashboard');
        setDashboardMenu('Alertas');
      } else if (hash === 'relatorios') {
        setCurrentScreen('dashboard');
        setDashboardMenu('Relatórios');
      } else if (hash === 'produtos') {
        setCurrentScreen('dashboard');
        setDashboardMenu('Produtos');
      } else if (hash === 'compras') {
        setCurrentScreen('dashboard');
        setDashboardMenu('Compras');
      } else if (hash === 'estoque') {
        setCurrentScreen('dashboard');
        setDashboardMenu('Estoque');
      } else if (hash === 'solicitacoes') {
        setCurrentScreen('dashboard');
        setDashboardMenu('Solicitações');
      } else if (hash === 'fornecedores') {
        setCurrentScreen('dashboard');
        setDashboardMenu('Fornecedores');
      } else if (hash === 'login') {
        setCurrentScreen('login');
      } else if (hash === 'cadastro') {
        setCurrentScreen('cadastro');
      } else if (hash === 'esqueceu' || hash === 'esqueceu-senha') {
        setCurrentScreen('esqueceu-senha');
      } else if (hash === 'dashboard') {
        setCurrentScreen('dashboard');
        setDashboardMenu('Dashboard');
      } else if (hash === 'index' || hash === 'inicio') {
        setCurrentScreen('index');
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const handleSelectProfile = (perfil: 'aluno' | 'professor') => {
    setUserProfile(perfil);
    setCurrentScreen('login');
  };

  const irParaDashboardMenu = (menu: string) => {
    setDashboardMenu(menu);
    setCurrentScreen('dashboard');
  };

  const copiarCodigo = (texto: string) => {
    navigator.clipboard.writeText(texto);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2000);
  };

  // Se estiver em outra tela, renderiza a tela com navegação ativa
  if (currentScreen === 'login') {
    return (
      <div className="relative">
        <LoginScreen userType={userProfile} onNavigate={setCurrentScreen} />
        {renderBarraNavegacao()}
      </div>
    );
  }

  if (currentScreen === 'cadastro') {
    return (
      <div className="relative">
        <CadastroScreen onNavigate={setCurrentScreen} />
        {renderBarraNavegacao()}
      </div>
    );
  }

  if (currentScreen === 'esqueceu-senha') {
    return (
      <div className="relative">
        <EsqueceuSenhaScreen onNavigate={setCurrentScreen} />
        {renderBarraNavegacao()}
      </div>
    );
  }

  if (currentScreen === 'dashboard') {
    return (
      <div className="relative">
        <DashboardScreen onNavigate={setCurrentScreen} initialMenu={dashboardMenu} />
        {renderBarraNavegacao()}
      </div>
    );
  }

  // TELA INICIAL (Escolha de Perfil: Aluno / Professor)
  return (
    <div className="relative">
      <main>
        <section className="tela-acesso" aria-labelledby="titulo-acesso">
          {/* Imagem de fundoxx */}
          <img
            className="imagem-fundo"
            src="/img/fundo.png"
            alt="Fundo com estrutura molecular de DNA azul brilhante"
            aria-hidden="true"
          />

          {/* Conteudo de asexo hihiha */}
          <article className="painel-acesso">
            <header className="cabecalho-acesso">
              {/* Logo fiel ao Figma */}
              <div className="logo" style={{ cursor: 'pointer', maxWidth: '210px', margin: '0 auto' }}>
                <Logo width="100%" variant="light" />
              </div>

              {/* Textoxxxx */}
              <div className="informacao-acesso">
                <h1 id="titulo-acesso">Acesso</h1>
                <p>Escolha abaixo um perfil para acessar.</p>
              </div>

              {/* Perfixx com navegação direta para a tela de login */}
              <nav className="navegacao-perfis" aria-label="Escolha um perfil">
                <button
                  type="button"
                  className="botao-perfil"
                  onClick={() => handleSelectProfile('aluno')}
                  id="btn-aluno"
                >
                  <span>Aluno</span>
                  <span className="seta" aria-hidden="true">&rarr;</span>
                </button>

                <button
                  type="button"
                  className="botao-perfil"
                  onClick={() => handleSelectProfile('professor')}
                  id="btn-professor"
                >
                  <span>Professor(a)</span>
                  <span className="seta" aria-hidden="true">&rarr;</span>
                </button>
              </nav>
            </header>
          </article>
        </section>
      </main>

      {renderBarraNavegacao()}
    </div>
  );

  // Barra de navegação e atalhos rápidos flutuante no rodapé
  function renderBarraNavegacao() {
    return (
      <>
        <div className="fixed bottom-3 left-1/2 -translate-x-1/2 z-50 flex items-center gap-1.5 p-1.5 rounded-full bg-zinc-950/90 border border-zinc-800 shadow-2xl backdrop-blur-md max-w-[95vw] overflow-x-auto">
          {/* Botão de telas */}
          <span className="text-[11px] font-semibold text-zinc-400 pl-3 pr-1 hidden sm:inline">
            Telas do Figma:
          </span>

          <button
            onClick={() => setCurrentScreen('index')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap ${
              currentScreen === 'index'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
            }`}
          >
            Início (Perfis)
          </button>

          <button
            onClick={() => setCurrentScreen('login')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap ${
              currentScreen === 'login'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
            }`}
          >
            Login
          </button>

          <button
            onClick={() => setCurrentScreen('cadastro')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap ${
              currentScreen === 'cadastro'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
            }`}
          >
            Cadastro
          </button>

          <button
            onClick={() => setCurrentScreen('esqueceu-senha')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap ${
              currentScreen === 'esqueceu-senha'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
            }`}
          >
            Esqueceu Senha
          </button>

          <button
            onClick={() => irParaDashboardMenu('Dashboard')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap ${
              currentScreen === 'dashboard' && dashboardMenu === 'Dashboard'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
            }`}
          >
            Dashboard
          </button>

          <button
            onClick={() => irParaDashboardMenu('Alertas')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap flex items-center gap-1.5 ${
              currentScreen === 'dashboard' && dashboardMenu === 'Alertas'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
            }`}
          >
            <span>Alertas</span>
            <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-400 text-black">
              15
            </span>
          </button>

          <button
            onClick={() => irParaDashboardMenu('Relatórios')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition whitespace-nowrap ${
              currentScreen === 'dashboard' && dashboardMenu === 'Relatórios'
                ? 'bg-blue-600 text-white shadow-sm'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800'
            }`}
          >
            Relatórios
          </button>

          <div className="h-4 w-[1px] bg-zinc-700 mx-1 hidden sm:block" />

          {/* Botão para ver e copiar os arquivos HTML e CSS prontos para o XAMPP */}
          <button
            onClick={() => setModalCodigo('arquivos')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-cyan-300 text-xs font-semibold transition whitespace-nowrap"
            title="Ver arquivos prontos para copiar no XAMPP"
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Arquivos XAMPP</span>
          </button>
        </div>

        {/* Modal de visualização dos arquivos HTML/CSS para o XAMPP */}
        {modalCodigo && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <div className="w-full max-w-3xl max-h-[90vh] flex flex-col rounded-2xl bg-zinc-950 border border-zinc-800 text-white shadow-2xl overflow-hidden">
              <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-zinc-900/60">
                <div className="flex items-center gap-2">
                  <FolderTree className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-sm font-semibold">
                    Arquivos HTML & CSS interligados para o seu projeto XAMPP
                  </h3>
                </div>
                <button
                  onClick={() => setModalCodigo(null)}
                  className="text-zinc-400 hover:text-white p-1 rounded hover:bg-zinc-800"
                >
                  ✕
                </button>
              </div>

              <div className="p-5 overflow-y-auto space-y-4 text-xs">
                <div className="p-3 bg-cyan-950/40 border border-cyan-500/30 rounded-lg text-cyan-200">
                  <p className="font-semibold mb-1">
                    Estrutura de arquivos recomendada no seu XAMPP (htdocs/materia_reativa):
                  </p>
                  <p className="text-zinc-300 text-[11px] leading-relaxed font-mono">
                    📁 materia_reativa/<br />
                    ├── 📄 index.html &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Escolha de perfil: Aluno / Professor)<br />
                    ├── 📄 login.html &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Tela de login com onda do DNA e perfis)<br />
                    ├── 📄 aluno.html &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Área de login do Aluno)<br />
                    ├── 📄 professor.html &nbsp;&nbsp;(Área de login do Professor/Coordenador)<br />
                    ├── 📄 cadastro.html &nbsp;&nbsp;&nbsp;(Tela de cadastro com onda do DNA)<br />
                    ├── 📄 esqueceu.html &nbsp;&nbsp;&nbsp;(Tela de redefinição de senha)<br />
                    ├── 📄 dashboard.html &nbsp;&nbsp;(Painel com métricas, gráficos e últimas solicitações)<br />
                    ├── 📄 produtos.html &nbsp;&nbsp;&nbsp;(Catálogo e CRUD de reagentes químicos)<br />
                    ├── 📄 fornecedores.html (Gestão de fornecedores e cotações)<br />
                    ├── 📄 solicitacoes.html (Pedidos de materiais e aprovação docente)<br />
                    ├── 📄 compras.html &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Ordens de compra e recebimentos)<br />
                    ├── 📄 estoque.html &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Balanço físico, lotes e validades)<br />
                    ├── 📄 relatorios.html &nbsp;&nbsp;(Mapas da Polícia Federal, Exército e CONAMA)<br />
                    ├── 📄 alertas.html &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Central de alertas críticos e estoque baixo)<br />
                    ├── 📁 css/<br />
                    │&nbsp;&nbsp;&nbsp;└── 📄 style.css &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Estilo centralizado de todas as páginas)<br />
                    └── 📁 img/<br />
                    &nbsp;&nbsp;&nbsp;&nbsp;├── 🖼️ fundo.png &nbsp;&nbsp;&nbsp;&nbsp;(DNA molecular 3D)<br />
                    &nbsp;&nbsp;&nbsp;&nbsp;└── 🖼️ logo.png &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Logomarca com béquer)
                  </p>
                </div>

                <div className="space-y-3">
                  <p className="font-semibold text-zinc-200 text-sm">
                    Links de conexão entre as telas:
                  </p>
                  <ul className="list-disc list-inside text-zinc-300 space-y-1.5 leading-relaxed">
                    <li>
                      Em <strong className="text-white">index.html</strong>: Os botões de <em>Aluno</em> e <em>Professor(a)</em> direcionam para <code className="text-blue-400 bg-zinc-900 px-1 py-0.5 rounded">login.html</code>.
                    </li>
                    <li>
                      Em <strong className="text-white">login.html</strong>: O link <em>Esqueceu sua senha?</em> leva para <code className="text-blue-400 bg-zinc-900 px-1 py-0.5 rounded">esqueceu.html</code>, o link <em>cadastre-se</em> leva para <code className="text-blue-400 bg-zinc-900 px-1 py-0.5 rounded">cadastro.html</code>, e o botão <em>Entrar</em> leva para <code className="text-blue-400 bg-zinc-900 px-1 py-0.5 rounded">dashboard.html</code>.
                    </li>
                    <li>
                      Em <strong className="text-white">dashboard.html</strong>: O botão do perfil <em>Katia Eliana</em> no canto inferior esquerdo possui a opção <em>Sair</em> que retorna para <code className="text-blue-400 bg-zinc-900 px-1 py-0.5 rounded">login.html</code> ou <code className="text-blue-400 bg-zinc-900 px-1 py-0.5 rounded">index.html</code>.
                    </li>
                  </ul>
                </div>
              </div>

              <div className="px-5 py-3 border-t border-zinc-800 bg-zinc-900/60 flex justify-end">
                <button
                  onClick={() => setModalCodigo(null)}
                  className="px-4 py-2 rounded-lg bg-white text-black font-semibold text-xs hover:bg-zinc-200 transition"
                >
                  Entendi, fechar
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }
}
