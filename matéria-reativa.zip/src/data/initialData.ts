import { ProdutoQuimico, Fornecedor, SolicitacaoLaboratorio, CompraItem, EstoqueItem } from '../types';

export const initialProdutos: ProdutoQuimico[] = [
  {
    id: 'PRD-01',
    nome: 'ACETONA',
    cas: '67-64-1',
    formulaQuimica: 'CH₃COCH₃',
    massaMolar: '58.08 g/mol',
    pureza: '99.5% P.A.',
    classePerigo: 'Líquido Inflamável Cat. 2',
    corPerigo: 'amarelo',
    situacao: 'Controlado',
    estoqueAtual: 3.5,
    estoqueMinimo: 2.0,
    unidade: 'L',
    validade: '10/2027',
    localizacao: 'Armário de Inflamáveis 01',
    fornecedorPrincipal: 'CRQ Produtos Químicos Eireli'
  },
  {
    id: 'PRD-02',
    nome: 'ÁCIDO SULFÚRICO',
    cas: '7664-93-9',
    formulaQuimica: 'H₂SO₄',
    massaMolar: '98.08 g/mol',
    pureza: '98.0% P.A.',
    classePerigo: 'Corrosivo Cat. 1A',
    corPerigo: 'vermelho',
    situacao: 'Controlado',
    estoqueAtual: 800,
    estoqueMinimo: 1000,
    unidade: 'mL',
    validade: '05/2027',
    localizacao: 'Capela de Exaustão / Corrosivos',
    fornecedorPrincipal: 'SP Labor Equipamentos'
  },
  {
    id: 'PRD-03',
    nome: 'BICARBONATO DE POTÁSSIO',
    cas: '298-14-6',
    formulaQuimica: 'KHCO₃',
    massaMolar: '100.11 g/mol',
    pureza: '99.7% P.A.',
    classePerigo: 'Não classificado como perigoso',
    corPerigo: 'verde',
    situacao: 'Não controlado',
    estoqueAtual: 2.5,
    estoqueMinimo: 1.0,
    unidade: 'kg',
    validade: '08/2028',
    localizacao: 'Prateleira Geral B-04',
    fornecedorPrincipal: 'Casa Americana de Artigos'
  },
  {
    id: 'PRD-04',
    nome: 'CAFEÍNA',
    cas: '58-08-2',
    formulaQuimica: 'C₈H₁₀N₄O₂',
    massaMolar: '194.19 g/mol',
    pureza: '99.0% Grau USP',
    classePerigo: 'Toxicidade Aguda Oral Cat. 4',
    corPerigo: 'verde',
    situacao: 'Não controlado',
    estoqueAtual: 350,
    estoqueMinimo: 200,
    unidade: 'g',
    validade: '12/2028',
    localizacao: 'Armário de Sólidos C-02',
    fornecedorPrincipal: 'Labsynth Produtos'
  },
  {
    id: 'PRD-05',
    nome: 'HIDRÓXIDO DE SÓDIO',
    cas: '1310-73-2',
    formulaQuimica: 'NaOH',
    massaMolar: '39.99 g/mol',
    pureza: '98.5% Micropérolas P.A.',
    classePerigo: 'Corrosivo Cat. 1A',
    corPerigo: 'vermelho',
    situacao: 'Controlado',
    estoqueAtual: 3.5,
    estoqueMinimo: 1.0,
    unidade: 'kg',
    validade: '04/2028',
    localizacao: 'Armário de Bases A-01',
    fornecedorPrincipal: 'CRQ Produtos Químicos Eireli'
  },
  {
    id: 'PRD-06',
    nome: 'CLORETO DE AMÔNIO',
    cas: '12125-02-9',
    formulaQuimica: 'NH₄Cl',
    massaMolar: '53.49 g/mol',
    pureza: '99.5% P.A.',
    classePerigo: 'Líquido Inflamável Cat. 4',
    corPerigo: 'amarelo',
    situacao: 'Controlado',
    estoqueAtual: 1.8,
    estoqueMinimo: 1.0,
    unidade: 'kg',
    validade: '09/2027',
    localizacao: 'Prateleira Reagentes D-03',
    fornecedorPrincipal: 'Casa Americana de Artigos'
  },
  {
    id: 'PRD-07',
    nome: 'PARACETAMOL',
    cas: '103-90-2',
    formulaQuimica: 'C₈H₉NO₂',
    massaMolar: '151.16 g/mol',
    pureza: '99.0% Farmacopeia',
    classePerigo: 'Líquido Inflamável Cat. 4',
    corPerigo: 'amarelo',
    situacao: 'Não controlado',
    estoqueAtual: 500,
    estoqueMinimo: 250,
    unidade: 'g',
    validade: '11/2027',
    localizacao: 'Armário Farmacêutico E-01',
    fornecedorPrincipal: 'Quimiglás vidros técnicos'
  },
  {
    id: 'PRD-08',
    nome: 'ÁCIDO FOSFÓRICO',
    cas: '7664-38-2',
    formulaQuimica: 'H₃PO₄',
    massaMolar: '98.00 g/mol',
    pureza: '85.0% P.A.',
    classePerigo: 'Corrosivo Cat. 1A',
    corPerigo: 'vermelho',
    situacao: 'Não controlado',
    estoqueAtual: 2.0,
    estoqueMinimo: 1.5,
    unidade: 'L',
    validade: '06/2027',
    localizacao: 'Armário de Ácidos B-02',
    fornecedorPrincipal: 'Labsynth Produtos'
  },
  {
    id: 'PRD-09',
    nome: 'BENZINA',
    cas: '8030-30-6',
    formulaQuimica: 'C₆-C₈ Hidrocarbonetos',
    massaMolar: '100-140 g/mol',
    pureza: 'Faixa 60-80°C P.A.',
    classePerigo: 'Líquido Inflamável Cat. 2',
    corPerigo: 'amarelo',
    situacao: 'Controlado',
    estoqueAtual: 1.2,
    estoqueMinimo: 1.0,
    unidade: 'L',
    validade: '01/2027',
    localizacao: 'Armário de Inflamáveis 02',
    fornecedorPrincipal: 'SP Labor Equipamentos'
  }
];

export const initialFornecedores: Fornecedor[] = [
  {
    id: 'FORN-01',
    razaoSocial: 'CRQ Produtos químicos Eireli',
    cnpj: '11.984.632/0001-27',
    contato: '(11) 2113-0238',
    endereco: 'Av. Eldorado, 182, Diadema - SP',
    email: 'vendas@crqmato.com.br',
    responsavel: 'Michele Oishi',
    status: 'Ativo',
    produtosFornecidos: ['Acetona', 'Hidróxido de Sódio', 'Glicerina']
  },
  {
    id: 'FORN-02',
    razaoSocial: 'Casa Americana de Artigos para Laboratórios Ltda.',
    cnpj: '60.812.718/0002-04',
    contato: '(11) 3334-2650',
    endereco: 'Rua Emílio Checchinato, 3959, São Roque das Chaves - Itupeva - SP',
    email: 'cristian.vendas@casamericana.com.br',
    responsavel: 'Cristian B. de S',
    status: 'Ativo',
    produtosFornecidos: ['Bicarbonato de Potássio', 'Nitrato de Potássio']
  },
  {
    id: 'FORN-03',
    razaoSocial: 'Casa Americana de Artigos para Laboratórios Ltda.',
    cnpj: '52.078.278/0001-98',
    contato: '(11) 5671-0100',
    endereco: 'Rua Viazza, 939 - SP',
    email: 'camila@prolab.com.br',
    responsavel: 'Camila',
    status: 'Ativo',
    produtosFornecidos: ['Vidrarias', 'Béqueres', 'Erlenmeyers']
  },
  {
    id: 'FORN-04',
    razaoSocial: 'Quimiglás vidros técnicos ltda',
    cnpj: '04.383.313/0001-08',
    contato: '(11) 2021-0874',
    endereco: 'Rua Ourinhos, 220, Vila Bertioga - SP',
    email: 'quimiglas@ig.com.br',
    responsavel: 'Sergio Palmezzano',
    status: 'Ativo',
    produtosFornecidos: ['Tubos de ensaio', 'Buretas', 'Pipetas']
  },
  {
    id: 'FORN-05',
    razaoSocial: 'SP Labor Equipamentos para Laboratório',
    cnpj: '04.093.087/0001-32',
    contato: '(18) 2104-9000',
    endereco: 'Rua Walt Disney, 155 - Vila Formosa - Presidente Prudente, CEP 19050-180',
    email: 'luan@splabor.com.br',
    responsavel: 'Luan',
    status: 'Ativo',
    produtosFornecidos: ['Ácido Sulfúrico', 'Xileno', 'Benzina']
  },
  {
    id: 'FORN-06',
    razaoSocial: 'Labsynth Produtos para Laboratórios Ltda.',
    cnpj: '51.462.471/0001-52',
    contato: '(11) 4072-6100',
    endereco: 'Av. Dr. Ulysses Guimarães, 3867 - Vila Mary, Diadema - SP - CEP: 09990-080',
    email: 'andrezavesari@synth.com.br',
    responsavel: 'Andreza Vesari',
    status: 'Ativo',
    produtosFornecidos: ['Reagentes P.A.', 'Corantes', 'Indicadores']
  },
  {
    id: 'FORN-07',
    razaoSocial: "Andrade's com de materiais para lab ltda",
    cnpj: '07.502.783/0001-70',
    contato: '(11) 5091-8222 / 0827/1851',
    endereco: 'Rua Eduardo Carlos Pereira, 430 - Alto do Ipiranga SP CEP: 04276-030',
    email: 'vendas@andradeslab.com.br',
    responsavel: 'Juliana Fontes',
    status: 'Ativo',
    produtosFornecidos: ['EPIs', 'Luvas Nitrílicas', 'Óculos de proteção']
  },
  {
    id: 'FORN-08',
    razaoSocial: 'RL Suprimentos e Insumos para laboratórios Ltda.',
    cnpj: '15.081.530/0001-00',
    contato: '(11) 2935-1626',
    endereco: 'Rua Prof. Djalma Bento, 389, CEP: 04578-020 Jardim Luanda, SP',
    email: 'vendas@rlsup.com.br',
    responsavel: 'Alberto',
    status: 'Ativo',
    produtosFornecidos: ['Filtros', 'Papel tornassol', 'Papel de pesagem']
  },
  {
    id: 'FORN-09',
    razaoSocial: 'RL Suprimentos e Insumos para laboratórios Ltda.',
    cnpj: '22.140.512/0001-33',
    contato: '(11) 4380-3889 / 4380-6023',
    endereco: 'Av. Elias Zugaib, 281 Piso Superior Bairro: Cidade Kemel - Poá - SP Cep: 08554-300',
    email: 'vendas@aecglass.com.br',
    responsavel: 'Roberto',
    status: 'Inativo',
    produtosFornecidos: ['Termômetros industriais']
  }
];

export const initialSolicitacoes: SolicitacaoLaboratorio[] = [
  {
    id: 'SOL-002',
    solicitante: 'Ana Silva',
    produto: 'Ácido Sulfúrico',
    quantidade: '2 L',
    orgao: 'Polícia Federal',
    data: '08/08/2026',
    status: 'Em análise',
    observacao: 'Uso exclusivo em aulas práticas de síntese orgânica'
  },
  {
    id: 'SOL-003',
    solicitante: 'Carlos Lima',
    produto: 'Acetona',
    quantidade: '5 L',
    orgao: 'Batalhão',
    data: '06/08/2026',
    status: 'Aprovada',
    observacao: 'Limpeza de vidrarias de precisão e extrações'
  },
  {
    id: 'SOL-004',
    solicitante: 'Maria Souza',
    produto: 'Nitrato de Potássio',
    quantidade: '1 kg',
    orgao: 'Batalhão',
    data: '05/08/2026',
    status: 'Pendência',
    observacao: 'Aguardando envio do comprovante de plano de aula detalhado'
  },
  {
    id: 'SOL-005',
    solicitante: 'Ana Silva',
    produto: 'Xileno',
    quantidade: '3 L',
    orgao: 'Polícia Federal',
    data: '02/08/2026',
    status: 'Aprovada',
    observacao: 'Preparo de lâminas histológicas'
  },
  {
    id: 'SOL-006',
    solicitante: 'Carlos Lima',
    produto: 'Magnésio Metálico',
    quantidade: '500 g',
    orgao: 'Órgão responsável',
    data: '30/07/2026',
    status: 'Reprovada',
    observacao: 'Capela sem sistema antichama para queima controlada'
  }
];

export const initialCompras: CompraItem[] = [
  {
    id: 'COM-001',
    produto: 'Acetona',
    quantidade: '5 L',
    fornecedor: 'CRQ Produtos químicos Eireli',
    valor: 420.00,
    data: '08/08/2026',
    status: 'Cotação'
  },
  {
    id: 'COM-002',
    produto: 'Ácido Sulfúrico',
    quantidade: '2 L',
    fornecedor: 'SP Labor Equipamentos para Laboratório',
    valor: 380.00,
    data: '07/08/2026',
    status: 'Aguardando aprovação'
  },
  {
    id: 'COM-003',
    produto: 'Nitrato de Potássio',
    quantidade: '1 kg',
    fornecedor: 'Casa Americana de Artigos para Laboratórios Ltda.',
    valor: 245.00,
    data: '05/08/2026',
    status: 'Pedido realizado'
  },
  {
    id: 'COM-004',
    produto: 'Glicerina',
    quantidade: '5 L',
    fornecedor: 'CRQ Produtos químicos Eireli',
    valor: 180.00,
    data: '02/08/2026',
    status: 'Recebido'
  },
  {
    id: 'COM-005',
    produto: 'Xileno',
    quantidade: '3 L',
    fornecedor: 'SP Labor Equipamentos para Laboratório',
    valor: 315.00,
    data: '01/08/2026',
    status: 'Cotação'
  }
];

export const initialEstoque: EstoqueItem[] = [
  {
    id: 'EST-01',
    produto: 'Acetona',
    cas: '67-64-1',
    formulaQuimica: 'CH₃COCH₃',
    quantidadeAtual: 3.5,
    unidade: 'L',
    estoqueMinimo: 2.0,
    validade: '10/2027',
    status: 'Normal',
    lote: 'LT-2024-884',
    localizacao: 'Armário de Inflamáveis 01',
    fornecedor: 'CRQ Produtos químicos Eireli'
  },
  {
    id: 'EST-02',
    produto: 'Ácido sulfúrico',
    cas: '7664-93-9',
    formulaQuimica: 'H₂SO₄',
    quantidadeAtual: 800,
    unidade: 'mL',
    estoqueMinimo: 1000,
    validade: '05/2027',
    status: 'Estoque baixo',
    lote: 'LT-2023-112',
    localizacao: 'Capela de Exaustão / Corrosivos',
    fornecedor: 'SP Labor Equipamentos'
  },
  {
    id: 'EST-03',
    produto: 'Bicarbonato de potássio',
    cas: '298-14-6',
    formulaQuimica: 'KHCO₃',
    quantidadeAtual: 2.5,
    unidade: 'kg',
    estoqueMinimo: 1.0,
    validade: '08/2028',
    status: 'Normal',
    lote: 'LT-2024-345',
    localizacao: 'Prateleira Geral B-04',
    fornecedor: 'Casa Americana de Artigos'
  },
  {
    id: 'EST-04',
    produto: 'Cafeína',
    cas: '58-08-2',
    formulaQuimica: 'C₈H₁₀N₄O₂',
    quantidadeAtual: 350,
    unidade: 'g',
    estoqueMinimo: 200,
    validade: '12/2028',
    status: 'Normal',
    lote: 'LT-2024-901',
    localizacao: 'Armário de Sólidos C-02',
    fornecedor: 'Labsynth Produtos'
  },
  {
    id: 'EST-05',
    produto: 'Iodo (Sublimado)',
    cas: '7553-56-2',
    formulaQuimica: 'I₂',
    quantidadeAtual: 120,
    unidade: 'g',
    estoqueMinimo: 250,
    validade: '03/2027',
    status: 'Estoque baixo',
    lote: 'LT-2023-440',
    localizacao: 'Armário de Oxirredutores D-01',
    fornecedor: 'Labsynth Produtos'
  },
  {
    id: 'EST-06',
    produto: 'Xileno',
    cas: '1330-20-7',
    formulaQuimica: 'C₆H₄(CH₃)₂',
    quantidadeAtual: 0,
    unidade: 'L',
    estoqueMinimo: 1.0,
    validade: '09/2027',
    status: 'Esgotado',
    lote: 'LT-2022-771',
    localizacao: 'Armário de Solventes 02',
    fornecedor: 'SP Labor Equipamentos'
  }
];
