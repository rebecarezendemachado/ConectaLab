export interface ProdutoQuimico {
  id: string;
  nome: string;
  cas: string;
  formulaQuimica?: string;
  massaMolar?: string;
  pureza?: string;
  classePerigo: string;
  corPerigo: 'amarelo' | 'vermelho' | 'verde' | 'laranja';
  fispqUrl?: string;
  notaFiscal?: string;
  situacao: 'Controlado' | 'Não controlado';
  estoqueAtual: number;
  estoqueMinimo: number;
  unidade: 'L' | 'mL' | 'kg' | 'g';
  validade: string;
  localizacao?: string;
  fornecedorPrincipal?: string;
}

export interface Fornecedor {
  id: string;
  razaoSocial: string;
  cnpj: string;
  contato: string;
  endereco: string;
  email: string;
  responsavel: string;
  status: 'Ativo' | 'Inativo';
  produtosFornecidos?: string[];
}

export interface SolicitacaoLaboratorio {
  id: string;
  solicitante: string;
  produto: string;
  quantidade: string;
  orgao: string;
  data: string;
  status: 'Em análise' | 'Aprovada' | 'Pendência' | 'Reprovada';
  observacao?: string;
}

export interface CompraItem {
  id: string;
  produto: string;
  quantidade: string;
  fornecedor: string;
  valor: number;
  data: string;
  status: 'Cotação' | 'Aguardando aprovação' | 'Pedido realizado' | 'Recebido';
}

export interface EstoqueItem {
  id: string;
  produto: string;
  cas: string;
  formulaQuimica?: string;
  quantidadeAtual: number;
  unidade: string;
  estoqueMinimo: number;
  validade: string;
  status: 'Normal' | 'Estoque baixo' | 'Esgotado';
  lote: string;
  localizacao?: string;
  fornecedor?: string;
}
