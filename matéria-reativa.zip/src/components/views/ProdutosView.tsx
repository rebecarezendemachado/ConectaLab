import React, { useState } from 'react';
import { ProdutoQuimico } from '../../types';
import {
  FlaskConical,
  AlertTriangle,
  FileText,
  Search,
  Plus,
  Eye,
  Edit2,
  Trash2,
  X,
  Download,
  CheckCircle2,
  ShieldAlert,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface ProdutosViewProps {
  produtos: ProdutoQuimico[];
  onAddProduto: (p: ProdutoQuimico) => void;
  onUpdateProduto: (p: ProdutoQuimico) => void;
  onDeleteProduto: (id: string) => void;
}

export const ProdutosView: React.FC<ProdutosViewProps> = ({
  produtos,
  onAddProduto,
  onUpdateProduto,
  onDeleteProduto
}) => {
  const [busca, setBusca] = useState('');
  const [filtroSituacao, setFiltroSituacao] = useState<'todos' | 'Controlados' | 'Não controlados'>('todos');
  const [pagina, setPagina] = useState(1);
  const [toast, setToast] = useState<string | null>(null);

  const mostrarToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  // Modais
  const [modalNovoAberto, setModalNovoAberto] = useState(false);
  const [modalEditar, setModalEditar] = useState<ProdutoQuimico | null>(null);
  const [modalVisualizar, setModalVisualizar] = useState<ProdutoQuimico | null>(null);
  const [modalPdf, setModalPdf] = useState<{ tipo: 'FISPQ' | 'Nota Fiscal'; produto: ProdutoQuimico } | null>(null);
  const [produtoParaExcluir, setProdutoParaExcluir] = useState<ProdutoQuimico | null>(null);

  // Filtragem
  const produtosFiltrados = produtos.filter((p) => {
    const matchBusca =
      p.nome.toLowerCase().includes(busca.toLowerCase()) ||
      p.cas.toLowerCase().includes(busca.toLowerCase()) ||
      p.classePerigo.toLowerCase().includes(busca.toLowerCase());
    const matchSituacao =
      filtroSituacao === 'todos' ||
      (filtroSituacao === 'Controlados' && p.situacao === 'Controlado') ||
      (filtroSituacao === 'Não controlados' && p.situacao === 'Não controlado');
    return matchBusca && matchSituacao;
  });

  const totalControlados = produtos.filter((p) => p.situacao === 'Controlado').length;
  const totalNaoControlados = produtos.filter((p) => p.situacao === 'Não controlado').length;
  const totalAtencao = produtos.filter((p) => p.estoqueAtual <= p.estoqueMinimo).length;

  const itensPorPagina = 9;
  const totalPaginas = Math.ceil(produtosFiltrados.length / itensPorPagina) || 1;
  const produtosExibidos = produtosFiltrados.slice((pagina - 1) * itensPorPagina, pagina * itensPorPagina);

  const getClassePerigoStyle = (classe: string) => {
    const lower = classe.toLowerCase();
    if (lower.includes('corrosivo')) {
      return 'bg-[#ff6b6b] text-white';
    }
    if (lower.includes('inflamável')) {
      return 'bg-[#ffde59] text-zinc-900';
    }
    if (lower.includes('não classificado') || lower.includes('perigoso')) {
      return 'bg-[#51cf66] text-white';
    }
    if (lower.includes('toxicidade')) {
      return 'bg-[#2b8a3e] text-white';
    }
    return 'bg-[#ffd43b] text-zinc-900';
  };

  return (
    <div className="space-y-4 relative">
      {/* Toast Feedback */}
      {toast && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 px-4 py-2.5 bg-zinc-900 text-white text-xs font-semibold rounded-xl shadow-2xl border border-zinc-700 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toast}</span>
        </div>
      )}
      {/* 4 CARDS DE MÉTRICAS FIÉIS À IMAGEM DO FIGMA */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        {/* Card 1: Produtos (243) com ícone de balão */}
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Produtos</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              243
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Total cadastrado</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <FlaskConical className="w-5 h-5" />
          </div>
        </div>

        {/* Card 2: Produção controlada (11) */}
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Produção controlada</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              11
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Polícia Fed. / Exército</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
        </div>

        {/* Card 3: Não controlados (8) */}
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Não controlados</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              8
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Uso livre no lab</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        {/* Card 4: Atenção (3) com ícone de triângulo */}
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Atenção</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              3
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Estoque baixo ou validade</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* BLOCO PRINCIPAL: CATÁLOGO DE PRODUTOS */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-zinc-200/70">
        {/* Cabeçalho do Bloco */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm font-bold text-zinc-900">Catálogo de produtos</h2>
            <p className="text-[11px] text-zinc-500">Consulte e gerencie os produtos químicos</p>
          </div>
          <button
            onClick={() => setModalNovoAberto(true)}
            className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#2F80ED] hover:bg-blue-600 active:scale-95 text-white text-xs font-semibold shadow-xs transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Novo Produto</span>
          </button>
        </div>

        {/* Barra de Filtros e Busca */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="relative w-full sm:w-72">
            <input
              type="text"
              value={busca}
              onChange={(e) => {
                setBusca(e.target.value);
                setPagina(1);
              }}
              placeholder="Pesquisar produto ou CAS..."
              className="w-full h-8 pl-3 pr-8 text-xs bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:border-[#2F80ED] focus:bg-white transition"
            />
            <Search className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400" />
          </div>

          <div className="flex items-center gap-1 bg-zinc-100/80 p-0.5 rounded-lg text-xs self-start sm:self-auto">
            <button
              onClick={() => setFiltroSituacao('todos')}
              className={`px-3 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                filtroSituacao === 'todos' ? 'bg-white text-zinc-900 shadow-2xs font-semibold' : 'text-zinc-500 hover:text-zinc-800'
              }`}
            >
              todos
            </button>
            <button
              onClick={() => setFiltroSituacao('Controlados')}
              className={`px-3 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                filtroSituacao === 'Controlados' ? 'bg-white text-zinc-900 shadow-2xs font-semibold' : 'text-zinc-500 hover:text-zinc-800'
              }`}
            >
              Controlados
            </button>
            <button
              onClick={() => setFiltroSituacao('Não controlados')}
              className={`px-3 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                filtroSituacao === 'Não controlados' ? 'bg-white text-zinc-900 shadow-2xs font-semibold' : 'text-zinc-500 hover:text-zinc-800'
              }`}
            >
              Não controlados
            </button>
          </div>
        </div>

        {/* Tabela de Produtos Química Fiel ao Figma */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-zinc-400 font-semibold border-b border-zinc-100">
                <th className="pb-2.5 pl-1">PRODUTO</th>
                <th className="pb-2.5">CAS</th>
                <th className="pb-2.5">CLASSE DE PERIGO</th>
                <th className="pb-2.5 text-center">FISPQ</th>
                <th className="pb-2.5 text-center">NOTA FISCAL</th>
                <th className="pb-2.5">SITUAÇÃO</th>
                <th className="pb-2.5 text-center pr-1">AÇÕES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {produtosExibidos.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-xs text-zinc-400">
                    Nenhum reagente encontrado com os filtros atuais.
                  </td>
                </tr>
              ) : (
                produtosExibidos.map((prod) => (
                  <tr key={prod.id} className="hover:bg-blue-50/20 transition group">
                    {/* Nome do Produto */}
                    <td className="py-2.5 pl-1">
                      <span className="font-semibold text-zinc-900 text-xs block leading-tight">
                        {prod.nome}
                      </span>
                      {prod.formulaQuimica && (
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="font-mono text-[10px] text-blue-600 font-semibold tracking-wide">
                            {prod.formulaQuimica}
                          </span>
                          {prod.pureza && (
                            <>
                              <span className="text-zinc-300 text-[9px]">·</span>
                              <span className="text-zinc-500 text-[10px]">{prod.pureza}</span>
                            </>
                          )}
                        </div>
                      )}
                    </td>

                    {/* Número CAS */}
                    <td className="py-2.5 font-mono text-zinc-500 text-[11px]">
                      {prod.cas}
                    </td>

                    {/* Classe de Perigo (Badge Colorido) */}
                    <td className="py-2.5">
                      <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${getClassePerigoStyle(prod.classePerigo)}`}>
                        {prod.classePerigo}
                      </span>
                    </td>

                    {/* FISPQ (Botão PDF) */}
                    <td className="py-2.5 text-center">
                      <button
                        onClick={() => setModalPdf({ tipo: 'FISPQ', produto: prod })}
                        className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-[#dbeafe] hover:bg-blue-200 text-[#1d4ed8] text-[10px] font-semibold transition cursor-pointer"
                        title="Abrir FISPQ em PDF"
                      >
                        <FileText className="w-3 h-3" />
                        <span>PDF</span>
                      </button>
                    </td>

                    {/* Nota Fiscal (Botão PDF) */}
                    <td className="py-2.5 text-center">
                      <button
                        onClick={() => setModalPdf({ tipo: 'Nota Fiscal', produto: prod })}
                        className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-[#dbeafe] hover:bg-blue-200 text-[#1d4ed8] text-[10px] font-semibold transition cursor-pointer"
                        title="Abrir Nota Fiscal em PDF"
                      >
                        <FileText className="w-3 h-3" />
                        <span>PDF</span>
                      </button>
                    </td>

                    {/* Situação */}
                    <td className="py-2.5">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold ${
                          prod.situacao === 'Controlado'
                            ? 'bg-[#2F80ED] text-white'
                            : 'bg-[#7c3aed] text-white'
                        }`}
                      >
                        {prod.situacao}
                      </span>
                    </td>

                    {/* Ações */}
                    <td className="py-2.5 pr-1 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Ver Detalhes */}
                        <button
                          onClick={() => setModalVisualizar(prod)}
                          className="p-1 rounded-md text-zinc-400 hover:text-blue-600 hover:bg-blue-50 transition cursor-pointer"
                          title="Ver detalhes"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {/* Editar */}
                        <button
                          onClick={() => setModalEditar(prod)}
                          className="p-1 rounded-md text-zinc-400 hover:text-amber-600 hover:bg-amber-50 transition cursor-pointer"
                          title="Editar reagente"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        {/* Excluir */}
                        <button
                          onClick={() => setProdutoParaExcluir(prod)}
                          className="p-1 rounded-md text-zinc-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                          title="Excluir reagente"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paginação fiel ao Figma */}
        <div className="flex items-center justify-center gap-1 mt-5 pt-3 border-t border-zinc-100">
          <button
            onClick={() => setPagina((p) => Math.max(1, p - 1))}
            disabled={pagina === 1}
            className="p-1 rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 transition"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          {[1, 2, 3].map((num) => (
            <button
              key={num}
              onClick={() => setPagina(num)}
              className={`w-7 h-7 rounded-md text-xs font-semibold transition ${
                pagina === num ? 'bg-[#2F80ED] text-white' : 'text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              {num}
            </button>
          ))}
          <button
            onClick={() => setPagina((p) => Math.min(totalPaginas, p + 1))}
            disabled={pagina === totalPaginas}
            className="p-1 rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 transition"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* MODAL: NOVO PRODUTO */}
      {modalNovoAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3.5 bg-zinc-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FlaskConical className="w-4 h-4 text-[#2F80ED]" />
                <h3 className="text-xs font-bold uppercase tracking-wider">Cadastrar Novo Produto Químico</h3>
              </div>
              <button onClick={() => setModalNovoAberto(false)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = new FormData(e.currentTarget);
                const novoProduto: ProdutoQuimico = {
                  id: `PRD-${Date.now().toString().slice(-4)}`,
                  nome: (form.get('nome') as string).toUpperCase(),
                  cas: form.get('cas') as string,
                  classePerigo: form.get('classePerigo') as string,
                  corPerigo: 'amarelo',
                  situacao: (form.get('situacao') as any) || 'Não controlado',
                  estoqueAtual: Number(form.get('estoqueAtual')) || 0,
                  estoqueMinimo: Number(form.get('estoqueMinimo')) || 1,
                  unidade: (form.get('unidade') as any) || 'L',
                  validade: (form.get('validade') as string) || '12/2027',
                  localizacao: form.get('localizacao') as string,
                  fornecedorPrincipal: form.get('fornecedor') as string
                };
                onAddProduto(novoProduto);
                setModalNovoAberto(false);
              }}
              className="p-5 space-y-3 text-xs"
            >
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-zinc-600 mb-1 font-medium">Nome do Produto</label>
                  <input
                    type="text"
                    name="nome"
                    required
                    placeholder="Ex: ÁCIDO CLORÍDRICO 37% P.A."
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Número CAS</label>
                  <input
                    type="text"
                    name="cas"
                    required
                    placeholder="Ex: 7647-01-0"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs font-mono focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Situação Legal</label>
                  <select
                    name="situacao"
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none bg-white"
                  >
                    <option value="Controlado">Controlado (PF / Exército)</option>
                    <option value="Não controlado">Não controlado</option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-zinc-600 mb-1 font-medium">Classe de Perigo (GHS)</label>
                  <input
                    type="text"
                    name="classePerigo"
                    required
                    defaultValue="Líquido Inflamável Cat. 2"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Estoque Inicial</label>
                  <input
                    type="number"
                    step="0.1"
                    name="estoqueAtual"
                    required
                    defaultValue="2.0"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Unidade de Medida</label>
                  <select
                    name="unidade"
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none bg-white"
                  >
                    <option value="L">Litros (L)</option>
                    <option value="mL">Mililitros (mL)</option>
                    <option value="kg">Quilogramas (kg)</option>
                    <option value="g">Gramas (g)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Estoque Mínimo</label>
                  <input
                    type="number"
                    step="0.1"
                    name="estoqueMinimo"
                    required
                    defaultValue="1.0"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Validade (MM/AAAA)</label>
                  <input
                    type="text"
                    name="validade"
                    required
                    placeholder="Ex: 08/2028"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-zinc-600 mb-1 font-medium">Localização no Laboratório</label>
                  <input
                    type="text"
                    name="localizacao"
                    placeholder="Ex: Armário de Inflamáveis 01"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-zinc-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalNovoAberto(false)}
                  className="px-3.5 py-1.5 text-xs text-zinc-600 hover:bg-zinc-100 rounded-lg transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-xs font-semibold shadow-xs transition"
                >
                  Cadastrar Reagente
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EDITAR PRODUTO */}
      {modalEditar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3.5 bg-zinc-900 text-white flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider">Editar Reagente: {modalEditar.nome}</h3>
              <button onClick={() => setModalEditar(null)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = new FormData(e.currentTarget);
                const atualizado: ProdutoQuimico = {
                  ...modalEditar,
                  nome: (form.get('nome') as string).toUpperCase(),
                  cas: form.get('cas') as string,
                  classePerigo: form.get('classePerigo') as string,
                  situacao: (form.get('situacao') as any) || 'Não controlado',
                  estoqueAtual: Number(form.get('estoqueAtual')) || 0,
                  estoqueMinimo: Number(form.get('estoqueMinimo')) || 1,
                  validade: form.get('validade') as string,
                  localizacao: form.get('localizacao') as string
                };
                onUpdateProduto(atualizado);
                setModalEditar(null);
              }}
              className="p-5 space-y-3 text-xs"
            >
              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="block text-zinc-600 mb-1 font-medium">Nome do Produto</label>
                  <input
                    type="text"
                    name="nome"
                    defaultValue={modalEditar.nome}
                    required
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">CAS</label>
                  <input
                    type="text"
                    name="cas"
                    defaultValue={modalEditar.cas}
                    required
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Situação</label>
                  <select
                    name="situacao"
                    defaultValue={modalEditar.situacao}
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs bg-white"
                  >
                    <option value="Controlado">Controlado</option>
                    <option value="Não controlado">Não controlado</option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-zinc-600 mb-1 font-medium">Classe de Perigo</label>
                  <input
                    type="text"
                    name="classePerigo"
                    defaultValue={modalEditar.classePerigo}
                    required
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Estoque Atual ({modalEditar.unidade})</label>
                  <input
                    type="number"
                    step="0.1"
                    name="estoqueAtual"
                    defaultValue={modalEditar.estoqueAtual}
                    required
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Estoque Mínimo</label>
                  <input
                    type="number"
                    step="0.1"
                    name="estoqueMinimo"
                    defaultValue={modalEditar.estoqueMinimo}
                    required
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-zinc-600 mb-1 font-medium">Localização</label>
                  <input
                    type="text"
                    name="localizacao"
                    defaultValue={modalEditar.localizacao}
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                  />
                </div>
              </div>
              <div className="pt-3 border-t border-zinc-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalEditar(null)}
                  className="px-3.5 py-1.5 text-xs text-zinc-600 hover:bg-zinc-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-xs font-semibold"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: VISUALIZAR DETALHES COMPLETOS */}
      {modalVisualizar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 bg-zinc-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-blue-400">{modalVisualizar.cas}</span>
                <h3 className="text-sm font-bold">{modalVisualizar.nome}</h3>
              </div>
              <button onClick={() => setModalVisualizar(null)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-100 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Classificação GHS:</span>
                  <span className="font-semibold text-zinc-800">{modalVisualizar.classePerigo}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Controle Legal:</span>
                  <span className={`font-semibold ${modalVisualizar.situacao === 'Controlado' ? 'text-blue-600' : 'text-purple-600'}`}>
                    {modalVisualizar.situacao}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Estoque no Laboratório:</span>
                  <strong className="text-zinc-900">{modalVisualizar.estoqueAtual} {modalVisualizar.unidade}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Ponto de Reposição (Mín):</span>
                  <span>{modalVisualizar.estoqueMinimo} {modalVisualizar.unidade}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Validade Atual:</span>
                  <span>{modalVisualizar.validade}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Armazenamento:</span>
                  <span>{modalVisualizar.localizacao || 'Armário Central de Reagentes'}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setModalVisualizar(null);
                    setModalPdf({ tipo: 'FISPQ', produto: modalVisualizar });
                  }}
                  className="flex-1 py-2 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Visualizar FISPQ</span>
                </button>
                <button
                  onClick={() => {
                    setModalVisualizar(null);
                    setModalPdf({ tipo: 'Nota Fiscal', produto: modalVisualizar });
                  }}
                  className="flex-1 py-2 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-800 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Nota Fiscal</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: VISUALIZADOR DE PDF / FISPQ / NOTA FISCAL */}
      {modalPdf && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-xl bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3.5 bg-zinc-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-blue-400" />
                <h3 className="text-xs font-bold uppercase tracking-wider">
                  {modalPdf.tipo} • {modalPdf.produto.nome}
                </h3>
              </div>
              <button onClick={() => setModalPdf(null)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-6 space-y-4 text-xs">
              <div className="border border-dashed border-zinc-300 rounded-xl p-6 text-center bg-zinc-50 space-y-2">
                <FileText className="w-10 h-10 text-[#2F80ED] mx-auto" />
                <h4 className="text-sm font-bold text-zinc-800">
                  Documento Oficial: {modalPdf.tipo} - {modalPdf.produto.nome}
                </h4>
                <p className="text-zinc-500 text-[11px] max-w-sm mx-auto">
                  {modalPdf.tipo === 'FISPQ'
                    ? `Ficha de Informações de Segurança de Produtos Químicos de acordo com a norma ABNT NBR 14725 e CAS ${modalPdf.produto.cas}.`
                    : `Nota Fiscal Eletrônica (Danfe) emitida pelo fornecedor principal ${modalPdf.produto.fornecedorPrincipal || 'Fornecedor Cadastrado'}.`}
                </p>
                <div className="pt-2">
                  <span className="inline-block px-2.5 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-full border border-emerald-200">
                    Arquivo Certificado Digitalmente • PDF
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => setModalPdf(null)}
                  className="px-4 py-2 rounded-lg text-xs text-zinc-600 hover:bg-zinc-100"
                >
                  Fechar
                </button>
                <button
                  onClick={() => {
                    mostrarToast(`Download do arquivo ${modalPdf.tipo} de ${modalPdf.produto.nome} concluído.`);
                    setModalPdf(null);
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-xs font-semibold shadow-xs"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar Arquivo PDF</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmação de Exclusão */}
      {produtoParaExcluir && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-zinc-200 p-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center flex-shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-zinc-900">Remover Reagente</h3>
                <p className="text-xs text-zinc-500">Esta ação excluirá o item do catálogo.</p>
              </div>
            </div>

            <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200 mb-4 text-xs space-y-1">
              <p className="font-semibold text-zinc-800">{produtoParaExcluir.nome}</p>
              <p className="text-zinc-500 font-mono text-[11px]">CAS: {produtoParaExcluir.cas}</p>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setProdutoParaExcluir(null)}
                className="px-3.5 py-2 rounded-lg text-xs text-zinc-600 hover:bg-zinc-100 font-medium transition"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  onDeleteProduto(produtoParaExcluir.id);
                  mostrarToast(`Reagente "${produtoParaExcluir.nome}" removido do catálogo.`);
                  setProdutoParaExcluir(null);
                }}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold shadow-xs transition active:scale-95"
              >
                Sim, Remover
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
