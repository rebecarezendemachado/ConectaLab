import React, { useState } from 'react';
import {
  BarChart3,
  Download,
  FileSpreadsheet,
  ShieldCheck,
  PieChart,
  TrendingUp,
  Calendar,
  X,
  CheckCircle2,
  FileText,
  Printer,
  FileCheck
} from 'lucide-react';

interface RelatorioPreview {
  titulo: string;
  orgao: string;
  codigoProtocolo: string;
  competencia: string;
  conteudo: {
    secao: string;
    itens: { chave: string; valor: string }[];
  }[];
}

export const RelatoriosView: React.FC = () => {
  const [docModal, setDocModal] = useState<RelatorioPreview | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const mostrarToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const abrirMapaDpf = () => {
    setDocModal({
      titulo: 'Mapa Mensal de Controle de Produtos Químicos - SIPROQUIM 2',
      orgao: 'Polícia Federal - DREX/SR/DPF',
      codigoProtocolo: 'SIPRO-2026-09882-BR',
      competencia: 'Setembro / 2026',
      conteudo: [
        {
          secao: 'Identificação da Instituição',
          itens: [
            { chave: 'Razão Social', valor: 'Escola Técnica Estadual - Laboratório de Química' },
            { chave: 'CNPJ', valor: '46.384.111/0001-40' },
            { chave: 'Certificado de Registro Cadastral (CRC)', valor: 'CRC-PF Nº 2024-8849-SP' },
            { chave: 'Responsável Técnico', valor: 'Profa. Dra. Katia Eliana (CRQ IV 04210984)' }
          ]
        },
        {
          secao: 'Balanço Físico de Controlados',
          itens: [
            { chave: 'Acetona P.A. (67-64-1)', valor: 'Saldo anterior: 4.5 L | Entradas: 0 L | Consumo: 1.0 L | Saldo atual: 3.5 L' },
            { chave: 'Ácido Sulfúrico 98% (7664-93-9)', valor: 'Saldo anterior: 1.2 L | Entradas: 0 L | Consumo: 0.4 L | Saldo atual: 0.8 L' },
            { chave: 'Hidróxido de Sódio P.A. (1310-73-2)', valor: 'Saldo anterior: 4.0 kg | Entradas: 0 kg | Consumo: 0.5 kg | Saldo atual: 3.5 kg' }
          ]
        },
        {
          secao: 'Status de Transmissão Eletrônica',
          itens: [
            { chave: 'Assinatura Digital', valor: 'ICP-Brasil e-CNPJ A3 Homologado' },
            { chave: 'Prazo Limite', valor: '10º dia útil de Outubro/2026' },
            { chave: 'Situação', valor: 'Consistência Validada sem Pendências' }
          ]
        }
      ]
    });
  };

  const abrirMapaDfpc = () => {
    setDocModal({
      titulo: 'Demonstrativo Trimestral de Precursores Químicos - Sistema DFPC',
      orgao: 'Exército Brasileiro - Comando da 2ª Região Militar',
      codigoProtocolo: 'EB-DFPC-2026-TRIM3-00412',
      competencia: '3º Trimestre / 2026',
      conteudo: [
        {
          secao: 'Título de Registro (TR)',
          itens: [
            { chave: 'Registro Militar', valor: 'TR Nº 11488/SP - Exército Brasileiro' },
            { chave: 'Atividade Autorizada', valor: 'Utilização e Armazenamento em Ensino Superior / Técnico' },
            { chave: 'Local de Depósito', valor: 'Bunker de Armazenamento Seguro A-01 / Capela de Exaustão' }
          ]
        },
        {
          secao: 'Itens Controlados sob Fiscalização Militar',
          itens: [
            { chave: 'Nitrato de Potássio P.A.', valor: 'Saldo atual: 1.25 kg (Finalidade: Análises qualitativas)' },
            { chave: 'Ácido Nítrico 65%', valor: 'Saldo atual: 0.50 L (Finalidade: Digestão ácida em capela)' },
            { chave: 'Permanganato de Potássio', valor: 'Saldo atual: 0.18 kg (Finalidade: Titulação redox)' }
          ]
        }
      ]
    });
  };

  const abrirManifestoMtr = () => {
    setDocModal({
      titulo: 'Manifesto de Transporte de Resíduos Perigosos (MTR - SINIR)',
      orgao: 'IBAMA / Ministério do Meio Ambiente e Mudança do Clima',
      codigoProtocolo: 'MTR-SINIR-SP-2026-99381',
      competencia: 'Setembro / 2026',
      conteudo: [
        {
          secao: 'Gerador do Resíduo',
          itens: [
            { chave: 'Origem', valor: 'Laboratório Pedagógico de Química Inorgânica e Orgânica' },
            { chave: 'Classe de Resíduo', valor: 'Classe I - Perigosos (ABNT NBR 10004)' },
            { chave: 'Acondicionamento', valor: 'Bombonas PEAD homologadas com batoque e respiro' }
          ]
        },
        {
          secao: 'Lotes de Resíduos Acondicionados',
          itens: [
            { chave: 'Galão R-01 (Solventes Halogenados)', valor: 'Volume: 6.2 L (Fração aquosa neutralizada)' },
            { chave: 'Galão R-02 (Solventes Não-Halogenados)', valor: 'Volume: 8.4 L (Acetona / Etanol / Propanol)' },
            { chave: 'Galão R-03 (Sais de Metais Pesados)', valor: 'Volume: 3.8 L (Cobre / Chumbo precipitados)' }
          ]
        }
      ]
    });
  };

  return (
    <div className="space-y-4">
      {/* Toast Feedback */}
      {toast && (
        <div className="fixed top-5 right-5 z-50 flex items-center gap-2 px-4 py-2.5 bg-zinc-900 text-white text-xs font-semibold rounded-xl shadow-2xl border border-zinc-700 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{toast}</span>
        </div>
      )}

      {/* 4 CARDS DE MÉTRICAS RELATÓRIOS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Consumo Mensal</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              R$ 24.560
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Dentro do orçamento</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Reagentes Utilizados</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              142 kg/L
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Aulas práticas de laboratório</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <PieChart className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Resíduos Descartados</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              18.4 L
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Tratados e neutralizados</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Conformidade Legal</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              100%
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">PF, Exército e Polícia Civil</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <BarChart3 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* BLOCO PRINCIPAL: RELATÓRIOS E AUDITORIA */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-zinc-200/70">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
          <div>
            <h2 className="text-sm font-bold text-zinc-900">Relatórios Gerenciais e de Auditoria</h2>
            <p className="text-[11px] text-zinc-500">Documentos fiscais e de prestação de contas aos órgãos fiscalizadores</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => mostrarToast('Relatório Consolidado (PDF) gerado com sucesso.')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-[#2F80ED] hover:bg-blue-600 active:scale-95 text-white text-xs font-semibold shadow-xs transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Exportar PDF</span>
            </button>
            <button
              onClick={() => mostrarToast('Planilha de Auditoria (XLSX) exportada com sucesso.')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-zinc-100 hover:bg-zinc-200 active:scale-95 text-zinc-700 text-xs font-semibold transition cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Exportar Excel</span>
            </button>
          </div>
        </div>

        {/* Grade com estatísticas e relatórios disponíveis */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl border border-zinc-200 bg-zinc-50/50 space-y-2 hover:border-blue-300 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-800">Mapa Mensal - Polícia Federal</span>
              <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Pronto para envio
              </span>
            </div>
            <p className="text-[11px] text-zinc-500">
              Demonstrativo de aquisição, estoque e consumo de produtos químicos controlados pelo DPF no mês de setembro.
            </p>
            <div className="pt-2 flex justify-between items-center text-[10.5px]">
              <span className="text-zinc-400">Competência: 09/2026</span>
              <button
                onClick={abrirMapaDpf}
                className="text-[#2F80ED] font-semibold hover:underline cursor-pointer flex items-center gap-1"
              >
                <FileText className="w-3 h-3" />
                <span>Gerar Mapa SIPROQUIM</span>
              </button>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-zinc-200 bg-zinc-50/50 space-y-2 hover:border-blue-300 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-800">Mapa Trimestral - Exército Brasileiro</span>
              <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Homologado
              </span>
            </div>
            <p className="text-[11px] text-zinc-500">
              Controle de precursores, oxidantes fortes e ácidos com restrição militar. Registrado no Sistema DFPC.
            </p>
            <div className="pt-2 flex justify-between items-center text-[10.5px]">
              <span className="text-zinc-400">Competência: 3º Trimestre</span>
              <button
                onClick={abrirMapaDfpc}
                className="text-[#2F80ED] font-semibold hover:underline cursor-pointer flex items-center gap-1"
              >
                <FileCheck className="w-3 h-3" />
                <span>Ver Mapa DFPC</span>
              </button>
            </div>
          </div>

          <div className="p-4 rounded-xl border border-zinc-200 bg-zinc-50/50 space-y-2 hover:border-blue-300 transition">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-zinc-800">Inventário de Descarte e Resíduos</span>
              <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                Atualizado
              </span>
            </div>
            <p className="text-[11px] text-zinc-500">
              Controle de galões de resíduos perigosos clorados, não clorados e sais pesados prontos para incineração.
            </p>
            <div className="pt-2 flex justify-between items-center text-[10.5px]">
              <span className="text-zinc-400">Última pesagem: 12/09/2026</span>
              <button
                onClick={abrirManifestoMtr}
                className="text-[#2F80ED] font-semibold hover:underline cursor-pointer flex items-center gap-1"
              >
                <FileText className="w-3 h-3" />
                <span>Manifesto MTR</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL DE PRÉ-VISUALIZAÇÃO OFICIAL DE DOCUMENTO */}
      {docModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-2xl max-h-[90vh] flex flex-col bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 bg-zinc-950 text-white flex items-center justify-between border-b border-zinc-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-blue-400 uppercase tracking-wide">
                    {docModal.codigoProtocolo}
                  </span>
                  <h3 className="text-sm font-bold text-white leading-tight">{docModal.titulo}</h3>
                </div>
              </div>
              <button
                onClick={() => setDocModal(null)}
                className="p-1 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 text-xs">
              <div className="flex items-center justify-between p-3 bg-zinc-50 rounded-xl border border-zinc-200">
                <div>
                  <span className="text-[10px] text-zinc-400 uppercase font-semibold block">Órgão Fiscalizador</span>
                  <strong className="text-zinc-900">{docModal.orgao}</strong>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-zinc-400 uppercase font-semibold block">Competência</span>
                  <span className="font-semibold text-blue-600">{docModal.competencia}</span>
                </div>
              </div>

              {docModal.conteudo.map((sec, idx) => (
                <div key={idx} className="space-y-2">
                  <h4 className="font-bold text-zinc-800 text-[11px] uppercase tracking-wider pb-1 border-b border-zinc-100">
                    {sec.secao}
                  </h4>
                  <div className="space-y-1.5 bg-zinc-50/70 p-3 rounded-lg border border-zinc-150">
                    {sec.itens.map((it, i) => (
                      <div key={i} className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-[11px]">
                        <span className="text-zinc-500 font-medium">{it.chave}:</span>
                        <span className="font-semibold text-zinc-800 text-right">{it.valor}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            <div className="px-5 py-3.5 bg-zinc-50 border-t border-zinc-200 flex items-center justify-between">
              <button
                onClick={() => setDocModal(null)}
                className="px-4 py-2 text-xs font-semibold text-zinc-600 hover:bg-zinc-200 rounded-lg transition"
              >
                Fechar
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    mostrarToast('Impressão oficial enviada para a fila de impressão.');
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-zinc-700 bg-white border border-zinc-300 rounded-lg hover:bg-zinc-100 transition"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Imprimir</span>
                </button>
                <button
                  onClick={() => {
                    mostrarToast(`Documento oficial baixado com autenticação digital.`);
                    setDocModal(null);
                  }}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-[#2F80ED] hover:bg-blue-600 rounded-lg shadow-xs transition active:scale-95"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Baixar Arquivo Autenticado</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
