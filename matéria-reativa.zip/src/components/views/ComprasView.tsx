import React, { useState } from 'react';
import { CompraItem, Fornecedor } from '../../types';
import {
  ShoppingBag,
  Clock,
  CheckCircle2,
  FileSpreadsheet,
  Search,
  Plus,
  Eye,
  X,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Trash2
} from 'lucide-react';

interface ComprasViewProps {
  compras: CompraItem[];
  fornecedores: Fornecedor[];
  produtosDisponiveis: string[];
  onAddCompra: (c: CompraItem) => void;
  onUpdateCompraStatus: (id: string, status: 'Cotação' | 'Aguardando aprovação' | 'Pedido realizado' | 'Recebido') => void;
  onDeleteCompra: (id: string) => void;
}

export const ComprasView: React.FC<ComprasViewProps> = ({
  compras,
  fornecedores,
  produtosDisponiveis,
  onAddCompra,
  onUpdateCompraStatus,
  onDeleteCompra
}) => {
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState<
    'Todos' | 'Cotação' | 'Aguardando aprovação' | 'Pedido realizado' | 'Recebido'
  >('Todos');
  const [pagina, setPagina] = useState(1);
  const [modalNovoAberto, setModalNovoAberto] = useState(false);
  const [modalVisualizar, setModalVisualizar] = useState<CompraItem | null>(null);
  const [compraParaExcluir, setCompraParaExcluir] = useState<CompraItem | null>(null);

  const comprasFiltradas = compras.filter((c) => {
    const matchBusca =
      c.id.toLowerCase().includes(busca.toLowerCase()) ||
      c.produto.toLowerCase().includes(busca.toLowerCase()) ||
      c.fornecedor.toLowerCase().includes(busca.toLowerCase());

    let matchStatus = true;
    if (filtroStatus !== 'Todos') {
      matchStatus = c.status === filtroStatus;
    }

    return matchBusca && matchStatus;
  });

  const totalPedidos = 24;
  const aguardando = compras.filter((c) => c.status === 'Aguardando aprovação').length + 3;
  const emCotacao = compras.filter((c) => c.status === 'Cotação').length + 4;
  const concluidos = compras.filter((c) => c.status === 'Recebido').length + 13;

  const itensPorPagina = 8;
  const totalPaginas = Math.ceil(comprasFiltradas.length / itensPorPagina) || 1;
  const exibidas = comprasFiltradas.slice((pagina - 1) * itensPorPagina, pagina * itensPorPagina);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Recebido':
        return 'bg-emerald-50 text-emerald-700 border-emerald-300';
      case 'Pedido realizado':
        return 'bg-purple-50 text-purple-700 border-purple-300';
      case 'Aguardando aprovação':
        return 'bg-amber-50 text-amber-700 border-amber-300';
      case 'Cotação':
      default:
        return 'bg-blue-50 text-blue-700 border-blue-300';
    }
  };

  return (
    <div className="space-y-4">
      {/* 4 CARDS DE MÉTRICAS FIGMA */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Total de pedidos</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {totalPedidos}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Processados este ano</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <ShoppingBag className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Aguardando aprovação</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {aguardando}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Reitoria / Finanças</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Em cotação</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {emCotacao}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Comparando propostas</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Concluídos</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {concluidos}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Materiais entregues</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* BLOCO PRINCIPAL: GESTÃO DE COMPRAS */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-zinc-200/70">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm font-bold text-zinc-900">Gestão de Compras</h2>
            <p className="text-[11px] text-zinc-500">Acompanhe pedidos, cotações e aquisições de reagentes</p>
          </div>
          <button
            onClick={() => setModalNovoAberto(true)}
            className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#2F80ED] hover:bg-blue-600 active:scale-95 text-white text-xs font-semibold shadow-xs transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Nova Compra</span>
          </button>
        </div>

        {/* Filtros e Busca */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="relative w-full sm:w-72">
            <input
              type="text"
              value={busca}
              onChange={(e) => {
                setBusca(e.target.value);
                setPagina(1);
              }}
              placeholder="Pesquisar pedido ou produto..."
              className="w-full h-8 pl-3 pr-8 text-xs bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:border-[#2F80ED] focus:bg-white transition"
            />
            <Search className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400" />
          </div>

          <div className="flex items-center gap-1 bg-zinc-100/80 p-0.5 rounded-lg text-xs self-start sm:self-auto flex-wrap">
            {(['Todos', 'Cotação', 'Aguardando aprovação', 'Pedido realizado', 'Recebido'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setFiltroStatus(st)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                  filtroStatus === st ? 'bg-white text-zinc-900 shadow-2xs font-semibold' : 'text-zinc-500 hover:text-zinc-800'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Tabela de Compras Fiel ao Figma */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-zinc-400 font-semibold border-b border-zinc-100">
                <th className="pb-2.5 pl-1">CÓDIGO</th>
                <th className="pb-2.5">PRODUTO</th>
                <th className="pb-2.5">QUANTIDADE</th>
                <th className="pb-2.5">FORNECEDOR</th>
                <th className="pb-2.5">VALOR TOTAL</th>
                <th className="pb-2.5">DATA</th>
                <th className="pb-2.5">STATUS</th>
                <th className="pb-2.5 text-center pr-1">AÇÕES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {exibidas.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-xs text-zinc-400">
                    Nenhum pedido de compra localizado com os filtros selecionados.
                  </td>
                </tr>
              ) : (
                exibidas.map((item) => (
                  <tr key={item.id} className="hover:bg-blue-50/20 transition group">
                    <td className="py-2.5 pl-1 font-semibold text-zinc-800 text-[11px]">
                      {item.id}
                    </td>
                    <td className="py-2.5 text-zinc-900 font-semibold text-[11px]">
                      {item.produto}
                    </td>
                    <td className="py-2.5 text-zinc-600 text-[11px]">
                      {item.quantidade}
                    </td>
                    <td className="py-2.5 text-zinc-600 text-[11px] max-w-[180px] truncate" title={item.fornecedor}>
                      {item.fornecedor}
                    </td>
                    <td className="py-2.5 font-semibold text-zinc-800 text-[11px]">
                      R$ {item.valor.toFixed(2).replace('.', ',')}
                    </td>
                    <td className="py-2.5 font-mono text-zinc-500 text-[10.5px]">
                      {item.data}
                    </td>
                    <td className="py-2.5">
                      <span className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${getStatusBadge(item.status)}`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="py-2.5 pr-1 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setModalVisualizar(item)}
                          className="p-1 rounded-md text-zinc-400 hover:text-blue-600 hover:bg-blue-50 transition cursor-pointer"
                          title="Ver detalhes da compra"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setCompraParaExcluir(item)}
                          className="p-1 rounded-md text-zinc-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                          title="Cancelar pedido de compra"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paginação */}
        <div className="flex items-center justify-center gap-1 mt-5 pt-3 border-t border-zinc-100">
          <button
            onClick={() => setPagina((p) => Math.max(1, p - 1))}
            disabled={pagina === 1}
            className="p-1 rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 transition"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          {[1, 2, 3].map((num) => (
            <button
              key={num}
              onClick={() => setPagina(num)}
              className={`w-7 h-7 rounded-md text-xs font-semibold transition ${
                pagina === num ? 'bg-[#2F80ED] text-white' : 'text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              {num}
            </button>
          ))}
          <button
            onClick={() => setPagina((p) => Math.min(totalPaginas, p + 1))}
            disabled={pagina === totalPaginas}
            className="p-1 rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 transition"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* MODAL NOVA COMPRA */}
      {modalNovoAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3.5 bg-zinc-900 text-white flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider">Novo Pedido de Compra</h3>
              <button onClick={() => setModalNovoAberto(false)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = new FormData(e.currentTarget);
                const nova: CompraItem = {
                  id: `COM-00${compras.length + 3}`,
                  produto: form.get('produto') as string,
                  quantidade: form.get('quantidade') as string,
                  fornecedor: form.get('fornecedor') as string,
                  valor: Number(form.get('valor')) || 0,
                  data: new Date().toLocaleDateString('pt-BR'),
                  status: (form.get('status') as any) || 'Cotação'
                };
                onAddCompra(nova);
                setModalNovoAberto(false);
              }}
              className="p-5 space-y-3 text-xs"
            >
              <div className="space-y-2.5">
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Reagente / Item Solicitado</label>
                  <select
                    name="produto"
                    required
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:border-[#2F80ED] focus:outline-none"
                  >
                    {produtosDisponiveis.map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">Quantidade</label>
                    <input
                      type="text"
                      name="quantidade"
                      required
                      placeholder="Ex: 5 L ou 2 kg"
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">Valor Estimado (R$)</label>
                    <input
                      type="number"
                      step="0.01"
                      name="valor"
                      required
                      placeholder="Ex: 350.00"
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Fornecedor Selecionado</label>
                  <select
                    name="fornecedor"
                    required
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:border-[#2F80ED] focus:outline-none"
                  >
                    {fornecedores.map((f) => (
                      <option key={f.id} value={f.razaoSocial}>
                        {f.razaoSocial}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Status Inicial</label>
                  <select
                    name="status"
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:border-[#2F80ED] focus:outline-none"
                  >
                    <option value="Cotação">Cotação</option>
                    <option value="Aguardando aprovação">Aguardando aprovação</option>
                    <option value="Pedido realizado">Pedido realizado</option>
                    <option value="Recebido">Recebido</option>
                  </select>
                </div>
              </div>
              <div className="pt-3 border-t border-zinc-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalNovoAberto(false)}
                  className="px-3.5 py-1.5 text-xs text-zinc-600 hover:bg-zinc-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-xs font-semibold"
                >
                  Criar Pedido de Compra
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL VISUALIZAR COMPRA */}
      {modalVisualizar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 bg-zinc-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-blue-400">{modalVisualizar.id}</span>
                <h3 className="text-sm font-bold">Ordem de Compra: {modalVisualizar.produto}</h3>
              </div>
              <button onClick={() => setModalVisualizar(null)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-100 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Produto Químico:</span>
                  <strong className="text-zinc-900">{modalVisualizar.produto}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Fornecedor:</span>
                  <span className="text-zinc-800">{modalVisualizar.fornecedor}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Volume Comprado:</span>
                  <span>{modalVisualizar.quantidade}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Valor Total:</span>
                  <strong className="text-[#2F80ED] text-sm">
                    R$ {modalVisualizar.valor.toFixed(2).replace('.', ',')}
                  </strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Data do Pedido:</span>
                  <span>{modalVisualizar.data}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-zinc-100 space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block">Atualizar Etapa:</span>
                <div className="grid grid-cols-2 gap-1.5">
                  {(['Cotação', 'Aguardando aprovação', 'Pedido realizado', 'Recebido'] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => {
                        onUpdateCompraStatus(modalVisualizar.id, st);
                        setModalVisualizar({ ...modalVisualizar, status: st });
                      }}
                      className={`py-1.5 px-2 rounded-lg text-xs font-semibold border transition ${
                        modalVisualizar.status === st
                          ? 'bg-[#2F80ED] text-white border-[#2F80ED]'
                          : 'bg-zinc-50 hover:bg-zinc-100 text-zinc-700 border-zinc-200'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-between items-center">
                <button
                  onClick={() => {
                    setCompraParaExcluir(modalVisualizar);
                  }}
                  className="text-rose-600 hover:underline text-xs flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Cancelar Pedido</span>
                </button>
                <button
                  onClick={() => setModalVisualizar(null)}
                  className="px-4 py-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-xs font-semibold"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Modal de Confirmação de Cancelamento de Pedido */}
      {compraParaExcluir && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-zinc-200 p-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center flex-shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-zinc-900">Cancelar Ordem de Compra</h3>
                <p className="text-xs text-zinc-500">Esta ação cancelará o pedido no sistema.</p>
              </div>
            </div>

            <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200 mb-4 text-xs space-y-1">
              <p className="font-semibold text-zinc-800">
                <span className="text-blue-600 font-mono">{compraParaExcluir.id}</span> · {compraParaExcluir.produto}
              </p>
              <div className="flex justify-between text-zinc-500 font-mono text-[11px]">
                <span>Qtd: {compraParaExcluir.quantidade}</span>
                <span>Total: R$ {compraParaExcluir.valor.toFixed(2)}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setCompraParaExcluir(null)}
                className="px-3.5 py-2 rounded-lg text-xs text-zinc-600 hover:bg-zinc-100 font-medium transition cursor-pointer"
              >
                Voltar
              </button>
              <button
                onClick={() => {
                  onDeleteCompra(compraParaExcluir.id);
                  if (modalVisualizar?.id === compraParaExcluir.id) setModalVisualizar(null);
                  setCompraParaExcluir(null);
                }}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold shadow-xs transition active:scale-95 cursor-pointer"
              >
                Sim, Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
