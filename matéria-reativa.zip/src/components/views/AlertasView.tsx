import React, { useState } from 'react';
import { AlertTriangle, ShieldAlert, CheckCircle2, ShoppingCart, RefreshCw, X, Bell } from 'lucide-react';

interface AlertaItem {
  id: string;
  tipo: 'critico' | 'baixo' | 'validade' | 'orgao';
  titulo: string;
  descricao: string;
  produto: string;
  atual: string;
  minimo: string;
  resolvido?: boolean;
}

export const AlertasView: React.FC<{ onNavigateToCompras?: () => void }> = ({ onNavigateToCompras }) => {
  const [alertas, setAlertas] = useState<AlertaItem[]>([
    {
      id: 'ALT-01',
      tipo: 'critico',
      titulo: 'Estoque em Nível Crítico',
      descricao: 'Volume abaixo de 30% do limite operacional de segurança.',
      produto: 'Ácido Sulfúrico 98% P.A.',
      atual: '450 mL',
      minimo: '1.5 L'
    },
    {
      id: 'ALT-02',
      tipo: 'critico',
      titulo: 'Estoque Esgotado',
      descricao: 'Frasco vazio. Solicitações de alunos de histologia pendentes.',
      produto: 'Xileno P.A.',
      atual: '0 L',
      minimo: '1.0 L'
    },
    {
      id: 'ALT-03',
      tipo: 'baixo',
      titulo: 'Estoque Abaixo do Mínimo',
      descricao: 'Consumo acelerado nas últimas 2 semanas.',
      produto: 'Ácido Clorídrico 37% P.A.',
      atual: '1.2 L',
      minimo: '2.0 L'
    },
    {
      id: 'ALT-04',
      tipo: 'validade',
      titulo: 'Validade Próxima do Fim',
      descricao: 'Vencimento em menos de 45 dias. Recomenda-se teste de pureza.',
      produto: 'Nitrato de Prata P.A.',
      atual: '45 g',
      minimo: '100 g'
    },
    {
      id: 'ALT-05',
      tipo: 'baixo',
      titulo: 'Estoque Baixo',
      descricao: 'Necessária abertura de cotação com fornecedores.',
      produto: 'Permanganato de Potássio',
      atual: '180 g',
      minimo: '500 g'
    },
    {
      id: 'ALT-06',
      tipo: 'orgao',
      titulo: 'Prazo do Relatório Polícia Federal',
      descricao: 'Envio mensal da movimentação obrigatório até o 10º dia útil.',
      produto: 'Controle Geral SIPROQUIM',
      atual: 'Pendente envio',
      minimo: '10/10/2026'
    }
  ]);

  const resolverAlerta = (id: string) => {
    setAlertas((prev) => prev.filter((a) => a.id !== id));
  };

  return (
    <div className="space-y-4">
      {/* 4 CARDS DE MÉTRICAS ALERTAS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Alertas Ativos</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {alertas.length}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Requerem atenção</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <Bell className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Nível Crítico</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {alertas.filter((a) => a.tipo === 'critico').length}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Reposição imediata</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Validades</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {alertas.filter((a) => a.tipo === 'validade').length}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Próximas do vencimento</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <RefreshCw className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Regulatórios</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {alertas.filter((a) => a.tipo === 'orgao').length}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Prazos de órgãos</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* BLOCO DE ALERTAS */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-zinc-200/70">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-zinc-900">Central de Alertas Operacionais</h2>
            <p className="text-[11px] text-zinc-500">Monitore itens que requerem compra imediata ou ação preventiva</p>
          </div>
        </div>

        {alertas.length === 0 ? (
          <div className="py-12 text-center text-xs text-zinc-500">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            <p className="font-semibold text-zinc-800">Nenhum alerta pendente no momento!</p>
            <p className="text-[11px] text-zinc-400">Todos os reagentes e documentos estão dentro dos padrões normais.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {alertas.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-xl border border-zinc-200/80 bg-zinc-50/40 hover:bg-white hover:border-blue-200 transition shadow-2xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        item.tipo === 'critico'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : item.tipo === 'validade'
                          ? 'bg-purple-50 text-purple-700 border border-purple-200'
                          : item.tipo === 'orgao'
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}
                    >
                      {item.titulo}
                    </span>
                    <button
                      onClick={() => resolverAlerta(item.id)}
                      className="text-zinc-400 hover:text-zinc-700 p-0.5 rounded cursor-pointer"
                      title="Dispensar alerta"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <h4 className="text-xs font-bold text-zinc-900">{item.produto}</h4>
                  <p className="text-[11px] text-zinc-500 mt-1">{item.descricao}</p>
                  <div className="mt-3 py-1 px-2 rounded-lg bg-zinc-100 text-[10.5px] flex justify-between text-zinc-600">
                    <span>Nível Atual: <strong>{item.atual}</strong></span>
                    <span>Mínimo: <strong>{item.minimo}</strong></span>
                  </div>
                </div>

                <div className="pt-3.5 mt-2 border-t border-zinc-100 flex items-center justify-between">
                  <button
                    onClick={() => resolverAlerta(item.id)}
                    className="text-[11px] text-zinc-500 hover:text-zinc-800 font-medium cursor-pointer"
                  >
                    Marcar como resolvido
                  </button>
                  {onNavigateToCompras && (
                    <button
                      onClick={onNavigateToCompras}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-[10.5px] font-semibold transition cursor-pointer"
                    >
                      <ShoppingCart className="w-3 h-3" />
                      <span>Comprar</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
