import React, { useState } from 'react';
import { SolicitacaoLaboratorio } from '../../types';
import {
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  Search,
  Plus,
  Eye,
  X,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Building,
  Check,
  Trash2
} from 'lucide-react';

interface SolicitacoesViewProps {
  solicitacoes: SolicitacaoLaboratorio[];
  onAddSolicitacao: (s: SolicitacaoLaboratorio) => void;
  onUpdateSolicitacaoStatus: (id: string, status: 'Em análise' | 'Aprovada' | 'Pendência' | 'Reprovada') => void;
  onDeleteSolicitacao?: (id: string) => void;
  produtosDisponiveis: string[];
}

export const SolicitacoesView: React.FC<SolicitacoesViewProps> = ({
  solicitacoes,
  onAddSolicitacao,
  onUpdateSolicitacaoStatus,
  onDeleteSolicitacao,
  produtosDisponiveis
}) => {
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState<'Todos' | 'Em análise' | 'Aprovadas' | 'Pendências' | 'Reprovadas'>('Todos');
  const [pagina, setPagina] = useState(1);
  const [modalNovoAberto, setModalNovoAberto] = useState(false);
  const [modalVisualizar, setModalVisualizar] = useState<SolicitacaoLaboratorio | null>(null);
  const [solicitacaoParaExcluir, setSolicitacaoParaExcluir] = useState<SolicitacaoLaboratorio | null>(null);

  const solicitacoesFiltradas = solicitacoes.filter((s) => {
    const matchBusca =
      s.id.toLowerCase().includes(busca.toLowerCase()) ||
      s.solicitante.toLowerCase().includes(busca.toLowerCase()) ||
      s.produto.toLowerCase().includes(busca.toLowerCase()) ||
      s.orgao.toLowerCase().includes(busca.toLowerCase());

    let matchStatus = true;
    if (filtroStatus === 'Em análise') matchStatus = s.status === 'Em análise';
    else if (filtroStatus === 'Aprovadas') matchStatus = s.status === 'Aprovada';
    else if (filtroStatus === 'Pendências') matchStatus = s.status === 'Pendência';
    else if (filtroStatus === 'Reprovadas') matchStatus = s.status === 'Reprovada';

    return matchBusca && matchStatus;
  });

  const total = 32;
  const emAnalise = solicitacoes.filter((s) => s.status === 'Em análise').length + 6;
  const aprovadas = solicitacoes.filter((s) => s.status === 'Aprovada').length + 19;
  const pendencias = solicitacoes.filter((s) => s.status === 'Pendência').length + 2;

  const itensPorPagina = 8;
  const totalPaginas = Math.ceil(solicitacoesFiltradas.length / itensPorPagina) || 1;
  const exibidas = solicitacoesFiltradas.slice((pagina - 1) * itensPorPagina, pagina * itensPorPagina);

  const getStatusBadge = (st: string) => {
    switch (st) {
      case 'Aprovada':
        return 'bg-[#70e000]/25 text-[#1b7a00] border-[#38b000]/40';
      case 'Em análise':
        return 'bg-[#2F80ED]/20 text-[#1d4ed8] border-[#2F80ED]/40';
      case 'Pendência':
        return 'bg-[#ffde59]/50 text-[#b45309] border-[#eab308]/60';
      case 'Reprovada':
        return 'bg-[#ff8fa3]/30 text-[#e11d48] border-[#f43f5e]/40';
      default:
        return 'bg-zinc-100 text-zinc-700';
    }
  };

  return (
    <div className="space-y-4">
      {/* 4 CARDS DE MÉTRICAS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Total de solicitações</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {total}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Exercício corrente</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <FileText className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Em análise</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {emAnalise}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Aguardando parecer</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Aprovadas</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {aprovadas}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Liberadas para uso</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Com pendência</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              {pendencias}
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Documentação incompleta</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* FLUXO DE APROVAÇÃO (FIGMA) */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-zinc-200/70">
        <div className="mb-4">
          <h3 className="text-sm font-bold text-zinc-900">Fluxo de Aprovação</h3>
          <p className="text-[11px] text-zinc-500">Acompanhe as etapas de uma solicitação</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Etapa 1 */}
          <div className="p-3.5 rounded-xl bg-blue-50/50 border border-blue-100 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#2F80ED] text-white flex items-center justify-center font-bold text-xs shadow-xs">
              <Check className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-[#2F80ED] block">Solicitação</span>
              <span className="text-[11px] text-zinc-500">Registrada</span>
            </div>
          </div>

          {/* Etapa 2 */}
          <div className="p-3.5 rounded-xl bg-blue-50/50 border border-blue-100 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#2F80ED] text-white flex items-center justify-center font-bold text-xs shadow-xs">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-[#2F80ED] block">Análise</span>
              <span className="text-[11px] text-zinc-500">Documentação</span>
            </div>
          </div>

          {/* Etapa 3 */}
          <div className="p-3.5 rounded-xl bg-blue-50/50 border border-blue-100 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#2F80ED] text-white flex items-center justify-center font-bold text-xs shadow-xs">
              <Building className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-[#2F80ED] block">Órgão responsável</span>
              <span className="text-[11px] text-zinc-500">Em análise</span>
            </div>
          </div>

          {/* Etapa 4 */}
          <div className="p-3.5 rounded-xl bg-blue-50/50 border border-blue-100 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#2F80ED] text-white flex items-center justify-center font-bold text-xs shadow-xs">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-semibold text-[#2F80ED] block">Aprovação</span>
              <span className="text-[11px] text-zinc-500">Liberada</span>
            </div>
          </div>
        </div>
      </div>

      {/* BLOCO PRINCIPAL: SOLICITAÇÕES RECENTES */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-zinc-200/70">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm font-bold text-zinc-900">Solicitações Recentes</h2>
            <p className="text-[11px] text-zinc-500">Acompanhe o andamento das solicitações de produtos</p>
          </div>
          <button
            onClick={() => setModalNovoAberto(true)}
            className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#2F80ED] hover:bg-blue-600 active:scale-95 text-white text-xs font-semibold shadow-xs transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Nova solicitação</span>
          </button>
        </div>

        {/* Filtros e Busca */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="relative w-full sm:w-72">
            <input
              type="text"
              value={busca}
              onChange={(e) => {
                setBusca(e.target.value);
                setPagina(1);
              }}
              placeholder="Pesquisar solicitação..."
              className="w-full h-8 pl-3 pr-8 text-xs bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:border-[#2F80ED] focus:bg-white transition"
            />
            <Search className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400" />
          </div>

          <div className="flex items-center gap-1 bg-zinc-100/80 p-0.5 rounded-lg text-xs self-start sm:self-auto flex-wrap">
            {(['Todos', 'Em análise', 'Aprovadas', 'Pendências', 'Reprovadas'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setFiltroStatus(st)}
                className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                  filtroStatus === st ? 'bg-white text-zinc-900 shadow-2xs font-semibold' : 'text-zinc-500 hover:text-zinc-800'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Tabela de Solicitações Fiel ao Figma */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-zinc-400 font-semibold border-b border-zinc-100">
                <th className="pb-2.5 pl-1">CÓDIGO</th>
                <th className="pb-2.5">SOLICITANTE</th>
                <th className="pb-2.5">PRODUTO</th>
                <th className="pb-2.5">QUANTIDADE</th>
                <th className="pb-2.5">ÓRGÃO</th>
                <th className="pb-2.5">DATA</th>
                <th className="pb-2.5">STATUS</th>
                <th className="pb-2.5 text-center pr-1">AÇÕES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {exibidas.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-xs text-zinc-400">
                    Nenhuma solicitação encontrada para os filtros selecionados.
                  </td>
                </tr>
              ) : (
                exibidas.map((item) => (
                  <tr key={item.id} className="hover:bg-blue-50/20 transition group">
                    <td className="py-2.5 pl-1 font-semibold text-zinc-800 text-[11px]">
                      {item.id}
                    </td>
                    <td className="py-2.5 text-zinc-700 font-medium text-[11px]">
                      {item.solicitante}
                    </td>
                    <td className="py-2.5 text-zinc-800 font-semibold text-[11px]">
                      {item.produto}
                    </td>
                    <td className="py-2.5 text-zinc-600 text-[11px]">
                      {item.quantidade}
                    </td>
                    <td className="py-2.5 text-zinc-600 text-[11px]">
                      {item.orgao}
                    </td>
                    <td className="py-2.5 font-mono text-zinc-500 text-[10.5px]">
                      {item.data}
                    </td>
                    <td className="py-2.5">
                      <span className={`inline-block px-3 py-0.5 rounded-full text-[10px] font-semibold border ${getStatusBadge(item.status)}`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="py-2.5 pr-1 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setModalVisualizar(item)}
                          className="p-1 rounded-md text-zinc-400 hover:text-blue-600 hover:bg-blue-50 transition cursor-pointer"
                          title="Ver e gerenciar solicitação"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {onDeleteSolicitacao && (
                          <button
                            onClick={() => setSolicitacaoParaExcluir(item)}
                            className="p-1 rounded-md text-zinc-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                            title="Excluir solicitação"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paginação */}
        <div className="flex items-center justify-center gap-1 mt-5 pt-3 border-t border-zinc-100">
          <button
            onClick={() => setPagina((p) => Math.max(1, p - 1))}
            disabled={pagina === 1}
            className="p-1 rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 transition"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          {[1, 2, 3].map((num) => (
            <button
              key={num}
              onClick={() => setPagina(num)}
              className={`w-7 h-7 rounded-md text-xs font-semibold transition ${
                pagina === num ? 'bg-[#2F80ED] text-white' : 'text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              {num}
            </button>
          ))}
          <button
            onClick={() => setPagina((p) => Math.min(totalPaginas, p + 1))}
            disabled={pagina === totalPaginas}
            className="p-1 rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 transition"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* MODAL NOVA SOLICITAÇÃO */}
      {modalNovoAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3.5 bg-zinc-900 text-white flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider">Registrar Solicitação de Reagente</h3>
              <button onClick={() => setModalNovoAberto(false)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = new FormData(e.currentTarget);
                const nova: SolicitacaoLaboratorio = {
                  id: `SOL-00${solicitacoes.length + 3}`,
                  solicitante: form.get('solicitante') as string,
                  produto: form.get('produto') as string,
                  quantidade: form.get('quantidade') as string,
                  orgao: form.get('orgao') as string,
                  data: new Date().toLocaleDateString('pt-BR'),
                  status: 'Em análise',
                  observacao: form.get('observacao') as string
                };
                onAddSolicitacao(nova);
                setModalNovoAberto(false);
              }}
              className="p-5 space-y-3 text-xs"
            >
              <div className="space-y-2.5">
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Nome do Solicitante (Docente)</label>
                  <input
                    type="text"
                    name="solicitante"
                    required
                    defaultValue="Prof. Carlos Lima"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Reagente ou Material</label>
                  <select
                    name="produto"
                    required
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:border-[#2F80ED] focus:outline-none"
                  >
                    {produtosDisponiveis.map((p) => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">Quantidade Solicitada</label>
                    <input
                      type="text"
                      name="quantidade"
                      required
                      placeholder="Ex: 2 L ou 500 g"
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">Órgão Regulador / Destino</label>
                    <select
                      name="orgao"
                      className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs bg-white focus:border-[#2F80ED] focus:outline-none"
                    >
                      <option value="Polícia Federal">Polícia Federal</option>
                      <option value="Batalhão">Batalhão (Exército)</option>
                      <option value="Órgão responsável">Órgão responsável interno</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Justificativa Pedagógica</label>
                  <textarea
                    name="observacao"
                    rows={2}
                    placeholder="Descreva o experimento prático e plano de segurança..."
                    className="w-full p-2 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
              </div>
              <div className="pt-3 border-t border-zinc-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalNovoAberto(false)}
                  className="px-3.5 py-1.5 text-xs text-zinc-600 hover:bg-zinc-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-xs font-semibold"
                >
                  Submeter Solicitação
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL VISUALIZAR E APROVAR/REPROVAR */}
      {modalVisualizar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 bg-zinc-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-blue-400">{modalVisualizar.id}</span>
                <h3 className="text-sm font-bold">Gerenciamento de Solicitação</h3>
              </div>
              <button onClick={() => setModalVisualizar(null)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-100 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Solicitante:</span>
                  <strong className="text-zinc-900">{modalVisualizar.solicitante}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Item Requisitado:</span>
                  <strong className="text-blue-600">{modalVisualizar.produto}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Volume:</span>
                  <span>{modalVisualizar.quantidade}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Órgão Regulador:</span>
                  <span>{modalVisualizar.orgao}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Data de Submissão:</span>
                  <span>{modalVisualizar.data}</span>
                </div>
                <div className="pt-1.5 border-t border-zinc-200/60 flex justify-between items-center">
                  <span className="text-zinc-400">Status Atual:</span>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${getStatusBadge(modalVisualizar.status)}`}>
                    {modalVisualizar.status}
                  </span>
                </div>
              </div>

              {modalVisualizar.observacao && (
                <div className="bg-blue-50/50 p-2.5 rounded-lg border border-blue-100 text-[11px] text-zinc-700">
                  <p className="font-semibold text-blue-900">Justificativa da Aula:</p>
                  <p>{modalVisualizar.observacao}</p>
                </div>
              )}

              <div className="pt-2 border-t border-zinc-100 space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400 block">Alterar Status:</span>
                <div className="grid grid-cols-3 gap-1.5">
                  <button
                    onClick={() => {
                      onUpdateSolicitacaoStatus(modalVisualizar.id, 'Reprovada');
                      setModalVisualizar(null);
                    }}
                    className="py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-semibold transition cursor-pointer"
                  >
                    Reprovar
                  </button>
                  <button
                    onClick={() => {
                      onUpdateSolicitacaoStatus(modalVisualizar.id, 'Pendência');
                      setModalVisualizar(null);
                    }}
                    className="py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-700 text-xs font-semibold transition cursor-pointer"
                  >
                    Pendência
                  </button>
                  <button
                    onClick={() => {
                      onUpdateSolicitacaoStatus(modalVisualizar.id, 'Aprovada');
                      setModalVisualizar(null);
                    }}
                    className="py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-semibold transition cursor-pointer"
                  >
                    Aprovar
                  </button>
                </div>
              </div>

              <div className="pt-2 flex justify-between items-center border-t border-zinc-100">
                {onDeleteSolicitacao && (
                  <button
                    type="button"
                    onClick={() => {
                      setSolicitacaoParaExcluir(modalVisualizar);
                    }}
                    className="text-rose-600 hover:text-rose-700 hover:underline text-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Excluir Solicitação</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setModalVisualizar(null)}
                  className="px-4 py-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold ml-auto transition cursor-pointer"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Modal de Confirmação de Exclusão de Solicitação */}
      {solicitacaoParaExcluir && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-zinc-200 p-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center flex-shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-zinc-900">Excluir Solicitação</h3>
                <p className="text-xs text-zinc-500">Esta ação cancelará a requisição.</p>
              </div>
            </div>

            <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200 mb-4 text-xs space-y-1">
              <p className="font-semibold text-zinc-800">
                <span className="text-blue-600 font-mono">{solicitacaoParaExcluir.id}</span> · {solicitacaoParaExcluir.solicitante}
              </p>
              <p className="text-zinc-500">{solicitacaoParaExcluir.produto} ({solicitacaoParaExcluir.quantidade})</p>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setSolicitacaoParaExcluir(null)}
                className="px-3.5 py-2 rounded-lg text-xs text-zinc-600 hover:bg-zinc-100 font-medium transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  if (onDeleteSolicitacao) onDeleteSolicitacao(solicitacaoParaExcluir.id);
                  if (modalVisualizar?.id === solicitacaoParaExcluir.id) setModalVisualizar(null);
                  setSolicitacaoParaExcluir(null);
                }}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold shadow-xs transition active:scale-95 cursor-pointer"
              >
                Sim, Excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
