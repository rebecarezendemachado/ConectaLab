import React, { useState } from 'react';
import { Fornecedor } from '../../types';
import {
  Truck,
  Building2,
  FileCheck2,
  XCircle,
  Search,
  Plus,
  Eye,
  Edit2,
  Trash2,
  X,
  Phone,
  Mail,
  MapPin,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface FornecedoresViewProps {
  fornecedores: Fornecedor[];
  onAddFornecedor: (f: Fornecedor) => void;
  onUpdateFornecedor: (f: Fornecedor) => void;
  onDeleteFornecedor: (id: string) => void;
}

export const FornecedoresView: React.FC<FornecedoresViewProps> = ({
  fornecedores,
  onAddFornecedor,
  onUpdateFornecedor,
  onDeleteFornecedor
}) => {
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState<'todos' | 'Ativos' | 'Inativos'>('todos');
  const [pagina, setPagina] = useState(1);

  // Modais
  const [modalNovoAberto, setModalNovoAberto] = useState(false);
  const [modalEditar, setModalEditar] = useState<Fornecedor | null>(null);
  const [modalVisualizar, setModalVisualizar] = useState<Fornecedor | null>(null);
  const [fornecedorParaExcluir, setFornecedorParaExcluir] = useState<Fornecedor | null>(null);

  const fornecedoresFiltrados = fornecedores.filter((f) => {
    const matchBusca =
      f.razaoSocial.toLowerCase().includes(busca.toLowerCase()) ||
      f.cnpj.includes(busca) ||
      f.responsavel.toLowerCase().includes(busca.toLowerCase()) ||
      f.email.toLowerCase().includes(busca.toLowerCase());
    const matchStatus =
      filtroStatus === 'todos' ||
      (filtroStatus === 'Ativos' && f.status === 'Ativo') ||
      (filtroStatus === 'Inativos' && f.status === 'Inativo');
    return matchBusca && matchStatus;
  });

  const totalAtivos = fornecedores.filter((f) => f.status === 'Ativo').length;
  const totalInativos = fornecedores.filter((f) => f.status === 'Inativo').length;

  const itensPorPagina = 9;
  const totalPaginas = Math.ceil(fornecedoresFiltrados.length / itensPorPagina) || 1;
  const fornecedoresExibidos = fornecedoresFiltrados.slice(
    (pagina - 1) * itensPorPagina,
    pagina * itensPorPagina
  );

  return (
    <div className="space-y-4">
      {/* 4 CARDS DE MÉTRICAS FIÉIS À TELA DE FORNECEDORES DO FIGMA */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
        {/* Card 1: Total de fornecedores (18) */}
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Total de fornecedores</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              18
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Empresas homologadas</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <Building2 className="w-5 h-5" />
          </div>
        </div>

        {/* Card 2: Fornecedores Ativos (15) */}
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Fornecedores Ativos</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              15
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Em operação regular</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <Truck className="w-5 h-5" />
          </div>
        </div>

        {/* Card 3: Cotações (7) */}
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Cotações</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              7
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Processos em andamento</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <FileCheck2 className="w-5 h-5" />
          </div>
        </div>

        {/* Card 4: Fornecedores Inativos (1) */}
        <div className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between min-h-[96px]">
          <div className="flex flex-col justify-center">
            <span className="text-xs font-medium text-blue-100">Fornecedores Inativos</span>
            <span className="text-2xl sm:text-[28px] font-bold tracking-tight text-white my-0.5 leading-none">
              1
            </span>
            <span className="text-[11px] text-blue-200/90 font-normal">Cadastro suspenso</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
            <XCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* BLOCO PRINCIPAL: LISTA DE FORNECEDORES */}
      <div className="bg-white rounded-2xl p-5 shadow-xs border border-zinc-200/70">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm font-bold text-zinc-900">Lista de Fornecedores</h2>
            <p className="text-[11px] text-zinc-500">Consulte e gerencie os fornecedores cadastrados.</p>
          </div>
          <button
            onClick={() => setModalNovoAberto(true)}
            className="flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-[#2F80ED] hover:bg-blue-600 active:scale-95 text-white text-xs font-semibold shadow-xs transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Cadastrar Fornecedor</span>
          </button>
        </div>

        {/* Filtros e Busca */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div className="relative w-full sm:w-72">
            <input
              type="text"
              value={busca}
              onChange={(e) => {
                setBusca(e.target.value);
                setPagina(1);
              }}
              placeholder="Pesquisar fornecedor, CNPJ..."
              className="w-full h-8 pl-3 pr-8 text-xs bg-zinc-50 border border-zinc-200 rounded-lg focus:outline-none focus:border-[#2F80ED] focus:bg-white transition"
            />
            <Search className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400" />
          </div>

          <div className="flex items-center gap-1 bg-zinc-100/80 p-0.5 rounded-lg text-xs self-start sm:self-auto">
            <button
              onClick={() => setFiltroStatus('todos')}
              className={`px-3 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                filtroStatus === 'todos' ? 'bg-white text-zinc-900 shadow-2xs font-semibold' : 'text-zinc-500 hover:text-zinc-800'
              }`}
            >
              todos
            </button>
            <button
              onClick={() => setFiltroStatus('Ativos')}
              className={`px-3 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                filtroStatus === 'Ativos' ? 'bg-white text-zinc-900 shadow-2xs font-semibold' : 'text-zinc-500 hover:text-zinc-800'
              }`}
            >
              Ativos
            </button>
            <button
              onClick={() => setFiltroStatus('Inativos')}
              className={`px-3 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                filtroStatus === 'Inativos' ? 'bg-white text-zinc-900 shadow-2xs font-semibold' : 'text-zinc-500 hover:text-zinc-800'
              }`}
            >
              Inativos
            </button>
          </div>
        </div>

        {/* Tabela de Fornecedores */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="text-[10px] uppercase tracking-wider text-zinc-400 font-semibold border-b border-zinc-100">
                <th className="pb-2.5 pl-1">FORNECEDORES</th>
                <th className="pb-2.5">CNPJ</th>
                <th className="pb-2.5">CONTATO</th>
                <th className="pb-2.5">ENDEREÇO</th>
                <th className="pb-2.5">E-MAIL</th>
                <th className="pb-2.5">RESPONSÁVEL</th>
                <th className="pb-2.5 text-center pr-1">AÇÕES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {fornecedoresExibidos.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-xs text-zinc-400">
                    Nenhum fornecedor localizado com os termos informados.
                  </td>
                </tr>
              ) : (
                fornecedoresExibidos.map((forn) => (
                  <tr key={forn.id} className="hover:bg-blue-50/20 transition group">
                    <td className="py-2.5 pl-1 font-semibold text-zinc-800 text-[11px] max-w-[170px] leading-tight">
                      {forn.razaoSocial}
                    </td>
                    <td className="py-2.5 font-mono text-zinc-500 text-[10px] whitespace-nowrap">
                      {forn.cnpj}
                    </td>
                    <td className="py-2.5 text-zinc-600 text-[10.5px] whitespace-nowrap">
                      {forn.contato}
                    </td>
                    <td className="py-2.5 text-zinc-500 text-[10.5px] max-w-[200px] truncate" title={forn.endereco}>
                      {forn.endereco}
                    </td>
                    <td className="py-2.5 text-[#2F80ED] underline text-[10.5px] max-w-[150px] truncate">
                      <a href={`mailto:${forn.email}`}>{forn.email}</a>
                    </td>
                    <td className="py-2.5 text-zinc-700 font-medium text-[11px]">
                      {forn.responsavel}
                    </td>
                    <td className="py-2.5 pr-1 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setModalVisualizar(forn)}
                          className="p-1 rounded-md text-zinc-400 hover:text-blue-600 hover:bg-blue-50 transition"
                          title="Ver detalhes"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setModalEditar(forn)}
                          className="p-1 rounded-md text-zinc-400 hover:text-amber-600 hover:bg-amber-50 transition"
                          title="Editar fornecedor"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setFornecedorParaExcluir(forn)}
                          className="p-1 rounded-md text-zinc-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                          title="Excluir fornecedor"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paginação */}
        <div className="flex items-center justify-center gap-1 mt-5 pt-3 border-t border-zinc-100">
          <button
            onClick={() => setPagina((p) => Math.max(1, p - 1))}
            disabled={pagina === 1}
            className="p-1 rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 transition"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          {[1, 2, 3].map((num) => (
            <button
              key={num}
              onClick={() => setPagina(num)}
              className={`w-7 h-7 rounded-md text-xs font-semibold transition ${
                pagina === num ? 'bg-[#2F80ED] text-white' : 'text-zinc-600 hover:bg-zinc-100'
              }`}
            >
              {num}
            </button>
          ))}
          <button
            onClick={() => setPagina((p) => Math.min(totalPaginas, p + 1))}
            disabled={pagina === totalPaginas}
            className="p-1 rounded-md border border-zinc-200 text-zinc-600 hover:bg-zinc-50 disabled:opacity-40 transition"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* MODAL CADASTRAR FORNECEDOR */}
      {modalNovoAberto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3.5 bg-zinc-900 text-white flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider">Novo Fornecedor de Reagentes</h3>
              <button onClick={() => setModalNovoAberto(false)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = new FormData(e.currentTarget);
                const novo: Fornecedor = {
                  id: `FORN-${Date.now().toString().slice(-4)}`,
                  razaoSocial: form.get('razaoSocial') as string,
                  cnpj: form.get('cnpj') as string,
                  contato: form.get('contato') as string,
                  endereco: form.get('endereco') as string,
                  email: form.get('email') as string,
                  responsavel: form.get('responsavel') as string,
                  status: (form.get('status') as any) || 'Ativo'
                };
                onAddFornecedor(novo);
                setModalNovoAberto(false);
              }}
              className="p-5 space-y-3 text-xs"
            >
              <div className="space-y-2.5">
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Razão Social / Nome Fantasia</label>
                  <input
                    type="text"
                    name="razaoSocial"
                    required
                    placeholder="Ex: LabTech Reagentes e Equipamentos Ltda"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">CNPJ</label>
                    <input
                      type="text"
                      name="cnpj"
                      required
                      placeholder="00.000.000/0001-00"
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs font-mono focus:border-[#2F80ED] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">Telefone / Contato</label>
                    <input
                      type="text"
                      name="contato"
                      required
                      placeholder="(11) 98765-4321"
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">E-mail Comercial</label>
                    <input
                      type="email"
                      name="email"
                      required
                      placeholder="vendas@empresa.com.br"
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">Responsável / Vendedor</label>
                    <input
                      type="text"
                      name="responsavel"
                      required
                      placeholder="Nome do contato"
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Endereço Completo</label>
                  <input
                    type="text"
                    name="endereco"
                    required
                    placeholder="Rua, número, bairro, cidade - UF, CEP"
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs focus:border-[#2F80ED] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Situação Cadastral</label>
                  <select
                    name="status"
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs bg-white"
                  >
                    <option value="Ativo">Ativo (Habilitado para cotações)</option>
                    <option value="Inativo">Inativo</option>
                  </select>
                </div>
              </div>
              <div className="pt-3 border-t border-zinc-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalNovoAberto(false)}
                  className="px-3.5 py-1.5 text-xs text-zinc-600 hover:bg-zinc-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-xs font-semibold"
                >
                  Salvar Fornecedor
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL EDITAR FORNECEDOR */}
      {modalEditar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3.5 bg-zinc-900 text-white flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase tracking-wider">Editar Fornecedor</h3>
              <button onClick={() => setModalEditar(null)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const form = new FormData(e.currentTarget);
                const atualizado: Fornecedor = {
                  ...modalEditar,
                  razaoSocial: form.get('razaoSocial') as string,
                  cnpj: form.get('cnpj') as string,
                  contato: form.get('contato') as string,
                  endereco: form.get('endereco') as string,
                  email: form.get('email') as string,
                  responsavel: form.get('responsavel') as string,
                  status: (form.get('status') as any) || 'Ativo'
                };
                onUpdateFornecedor(atualizado);
                setModalEditar(null);
              }}
              className="p-5 space-y-3 text-xs"
            >
              <div className="space-y-2.5">
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Razão Social</label>
                  <input
                    type="text"
                    name="razaoSocial"
                    defaultValue={modalEditar.razaoSocial}
                    required
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">CNPJ</label>
                    <input
                      type="text"
                      name="cnpj"
                      defaultValue={modalEditar.cnpj}
                      required
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">Telefone</label>
                    <input
                      type="text"
                      name="contato"
                      defaultValue={modalEditar.contato}
                      required
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">E-mail</label>
                    <input
                      type="email"
                      name="email"
                      defaultValue={modalEditar.email}
                      required
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-zinc-600 mb-1 font-medium">Responsável</label>
                    <input
                      type="text"
                      name="responsavel"
                      defaultValue={modalEditar.responsavel}
                      required
                      className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Endereço</label>
                  <input
                    type="text"
                    name="endereco"
                    defaultValue={modalEditar.endereco}
                    required
                    className="w-full h-8 px-2.5 border border-zinc-300 rounded-lg text-xs"
                  />
                </div>
                <div>
                  <label className="block text-zinc-600 mb-1 font-medium">Status</label>
                  <select
                    name="status"
                    defaultValue={modalEditar.status}
                    className="w-full h-8 px-2 border border-zinc-300 rounded-lg text-xs bg-white"
                  >
                    <option value="Ativo">Ativo</option>
                    <option value="Inativo">Inativo</option>
                  </select>
                </div>
              </div>
              <div className="pt-3 border-t border-zinc-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalEditar(null)}
                  className="px-3.5 py-1.5 text-xs text-zinc-600 hover:bg-zinc-100 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-xs font-semibold"
                >
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL VISUALIZAR FORNECEDOR */}
      {modalVisualizar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-4 bg-zinc-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-blue-400">{modalVisualizar.cnpj}</span>
                <h3 className="text-sm font-bold">{modalVisualizar.razaoSocial}</h3>
              </div>
              <button onClick={() => setModalVisualizar(null)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-3 text-xs">
              <div className="p-3 rounded-xl bg-zinc-50 border border-zinc-100 space-y-2">
                <div className="flex items-center gap-2 text-zinc-700">
                  <Phone className="w-3.5 h-3.5 text-blue-600" />
                  <span>{modalVisualizar.contato}</span>
                </div>
                <div className="flex items-center gap-2 text-zinc-700">
                  <Mail className="w-3.5 h-3.5 text-blue-600" />
                  <a href={`mailto:${modalVisualizar.email}`} className="text-[#2F80ED] underline">
                    {modalVisualizar.email}
                  </a>
                </div>
                <div className="flex items-start gap-2 text-zinc-700">
                  <MapPin className="w-3.5 h-3.5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <span>{modalVisualizar.endereco}</span>
                </div>
                <div className="pt-1 border-t border-zinc-200/60 flex justify-between">
                  <span className="text-zinc-500">Contato Responsável:</span>
                  <strong className="text-zinc-900">{modalVisualizar.responsavel}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-500">Status Cadastral:</span>
                  <span className={`font-semibold ${modalVisualizar.status === 'Ativo' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {modalVisualizar.status}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <button
                  onClick={() => setModalVisualizar(null)}
                  className="px-4 py-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-xs font-semibold"
                >
                  Fechar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Modal de Confirmação de Exclusão de Fornecedor */}
      {fornecedorParaExcluir && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl border border-zinc-200 p-5 animate-in fade-in zoom-in-95">
            <div className="flex items-center gap-3 text-red-600 mb-3">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center flex-shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-zinc-900">Excluir Fornecedor</h3>
                <p className="text-xs text-zinc-500">Esta ação removerá a empresa cadastrada.</p>
              </div>
            </div>

            <div className="p-3 bg-zinc-50 rounded-xl border border-zinc-200 mb-4 text-xs space-y-1">
              <p className="font-semibold text-zinc-800">{fornecedorParaExcluir.razaoSocial}</p>
              <p className="text-zinc-500 font-mono text-[11px]">CNPJ: {fornecedorParaExcluir.cnpj}</p>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setFornecedorParaExcluir(null)}
                className="px-3.5 py-2 rounded-lg text-xs text-zinc-600 hover:bg-zinc-100 font-medium transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                onClick={() => {
                  onDeleteFornecedor(fornecedorParaExcluir.id);
                  if (modalVisualizar?.id === fornecedorParaExcluir.id) setModalVisualizar(null);
                  setFornecedorParaExcluir(null);
                }}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-semibold shadow-xs transition active:scale-95 cursor-pointer"
              >
                Sim, Excluir
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
