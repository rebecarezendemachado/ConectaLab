import React, { useState, useEffect } from 'react';
import { Logo } from '../components/Logo';
import {
  Home,
  FlaskConical,
  Truck,
  FileText,
  ShoppingCart,
  Package,
  BarChart3,
  AlertTriangle,
  MoreVertical,
  LogOut,
  Bell,
  Search,
  CheckCircle2,
  XCircle,
  Menu,
  X,
  Plus,
  Download,
  User,
  Activity,
  Thermometer,
  ShieldCheck,
  Layers,
  Sparkles,
  ArrowRight,
  Command
} from 'lucide-react';
import {
  ProdutoQuimico,
  Fornecedor,
  SolicitacaoLaboratorio,
  CompraItem,
  EstoqueItem
} from '../types';
import {
  initialProdutos,
  initialFornecedores,
  initialSolicitacoes,
  initialCompras,
  initialEstoque
} from '../data/initialData';
import { ProdutosView } from '../components/views/ProdutosView';
import { FornecedoresView } from '../components/views/FornecedoresView';
import { SolicitacoesView } from '../components/views/SolicitacoesView';
import { ComprasView } from '../components/views/ComprasView';
import { EstoqueView } from '../components/views/EstoqueView';
import { RelatoriosView } from '../components/views/RelatoriosView';
import { AlertasView } from '../components/views/AlertasView';

interface DashboardScreenProps {
  onNavigate: (screen: 'index' | 'login' | 'cadastro' | 'esqueceu-senha' | 'dashboard') => void;
  initialMenu?: string;
}

interface SolicitacaoItem {
  id: string;
  professor: string;
  disciplina: string;
  data: string;
  itens: string[];
  turma: string;
  status: 'Aprovada' | 'Reprovada' | 'Pendente';
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({ onNavigate, initialMenu }) => {
  const [menuAtivo, setMenuAtivo] = useState(initialMenu || 'Dashboard');

  React.useEffect(() => {
    if (initialMenu) {
      setMenuAtivo(initialMenu);
    }
  }, [initialMenu]);
  const [menuUsuarioAberto, setMenuUsuarioAberto] = useState(false);
  const [sidebarMobileAberta, setSidebarMobileAberta] = useState(false);
  const [pontoSelecionado, setPontoSelecionado] = useState<{ mes: string; valor: string } | null>(null);
  const [categoriaHover, setCategoriaHover] = useState<string | null>(null);
  const [buscaSolicitacao, setBuscaSolicitacao] = useState('');
  const [filtroStatus, setFiltroStatus] = useState<'Todos' | 'Aprovada' | 'Pendente' | 'Reprovada'>('Todos');
  const [solicitacaoModal, setSolicitacaoModal] = useState<SolicitacaoItem | null>(null);
  const [notificacoesAbertas, setNotificacoesAbertas] = useState(false);
  const [novaSolicitacaoAberta, setNovaSolicitacaoAberta] = useState(false);
  const [spotlightAberto, setSpotlightAberto] = useState(false);
  const [buscaSpotlight, setBuscaSpotlight] = useState('');

  // Atalho de teclado global Ctrl+K / Cmd+K para abrir Spotlight
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSpotlightAberto((prev) => !prev);
      } else if (e.key === 'Escape' && spotlightAberto) {
        setSpotlightAberto(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [spotlightAberto]);

  // Estados Globais Funcionais para todos os Módulos do Sistema
  const [produtosQuimicos, setProdutosQuimicos] = useState<ProdutoQuimico[]>(initialProdutos);
  const [fornecedores, setFornecedores] = useState<Fornecedor[]>(initialFornecedores);
  const [solicitacoesLab, setSolicitacoesLab] = useState<SolicitacaoLaboratorio[]>(initialSolicitacoes);
  const [compras, setCompras] = useState<CompraItem[]>(initialCompras);
  const [estoque, setEstoque] = useState<EstoqueItem[]>(initialEstoque);

  // Manipuladores de CRUD de Produtos
  const handleAddProduto = (novo: ProdutoQuimico) => {
    setProdutosQuimicos((prev) => [novo, ...prev]);
    // Adicionar automaticamente ao estoque também
    const novoEstoque: EstoqueItem = {
      id: `EST-${novo.id}`,
      produto: novo.nome,
      cas: novo.cas,
      quantidadeAtual: novo.estoqueAtual,
      unidade: novo.unidade,
      estoqueMinimo: novo.estoqueMinimo,
      validade: novo.validade,
      status: novo.estoqueAtual <= 0 ? 'Esgotado' : novo.estoqueAtual <= novo.estoqueMinimo ? 'Estoque baixo' : 'Normal',
      lote: `LT-${Date.now().toString().slice(-6)}`
    };
    setEstoque((prev) => [novoEstoque, ...prev]);
  };

  const handleUpdateProduto = (atualizado: ProdutoQuimico) => {
    setProdutosQuimicos((prev) =>
      prev.map((p) => (p.id === atualizado.id ? atualizado : p))
    );
  };

  const handleDeleteProduto = (id: string) => {
    setProdutosQuimicos((prev) => prev.filter((p) => p.id !== id));
  };

  // Manipuladores de CRUD de Fornecedores
  const handleAddFornecedor = (novo: Fornecedor) => {
    setFornecedores((prev) => [novo, ...prev]);
  };

  const handleUpdateFornecedor = (atualizado: Fornecedor) => {
    setFornecedores((prev) =>
      prev.map((f) => (f.id === atualizado.id ? atualizado : f))
    );
  };

  const handleDeleteFornecedor = (id: string) => {
    setFornecedores((prev) => prev.filter((f) => f.id !== id));
  };

  // Manipuladores de Solicitações
  const handleAddSolicitacao = (nova: SolicitacaoLaboratorio) => {
    setSolicitacoesLab((prev) => [nova, ...prev]);
  };

  const handleUpdateSolicitacaoStatus = (
    id: string,
    status: 'Em análise' | 'Aprovada' | 'Pendência' | 'Reprovada'
  ) => {
    setSolicitacoesLab((prev) =>
      prev.map((s) => (s.id === id ? { ...s, status } : s))
    );
  };

  // Manipuladores de Compras
  const handleAddCompra = (nova: CompraItem) => {
    setCompras((prev) => [nova, ...prev]);
  };

  const handleUpdateCompraStatus = (
    id: string,
    status: 'Cotação' | 'Aguardando aprovação' | 'Pedido realizado' | 'Recebido'
  ) => {
    setCompras((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status } : c))
    );
  };

  const handleDeleteCompra = (id: string) => {
    setCompras((prev) => prev.filter((c) => c.id !== id));
  };

  // Manipuladores de Estoque
  const handleAddEstoque = (novo: EstoqueItem) => {
    setEstoque((prev) => [novo, ...prev]);
  };

  const handleUpdateEstoque = (atualizado: EstoqueItem) => {
    setEstoque((prev) =>
      prev.map((item) => (item.id === atualizado.id ? atualizado : item))
    );
  };

  const handleDeleteEstoque = (id: string) => {
    setEstoque((prev) => prev.filter((item) => item.id !== id));
  };

  const handleUpdateEstoqueQtd = (id: string, novaQtd: number) => {
    setEstoque((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const status =
            novaQtd <= 0
              ? 'Esgotado'
              : novaQtd <= item.estoqueMinimo
              ? 'Estoque baixo'
              : 'Normal';
          return { ...item, quantidadeAtual: novaQtd, status };
        }
        return item;
      })
    );
  };

  const handleAddMovimentacao = (id: string, tipo: 'entrada' | 'saida', qtd: number, motivo: string) => {
    console.log(`Movimentação registrada para ${id}: ${tipo} de ${qtd} (${motivo})`);
  };

  const handleDeleteSolicitacao = (id: string) => {
    setSolicitacoesLab((prev) => prev.filter((s) => s.id !== id));
  };

  const nomesProdutosDisponiveis = produtosQuimicos.map((p) => p.nome);

  // Lista de solicitações rápida para o widget do dashboard
  const [solicitacoes, setSolicitacoes] = useState<SolicitacaoItem[]>([
    {
      id: 'SOL-2024-005',
      professor: 'Prof. Ana Silva',
      disciplina: 'Química Orgânica II',
      data: '16/09/2024',
      turma: '3º Ano B',
      itens: ['Ácido Clorídrico 37% P.A. (500mL)', 'Éter Etílico P.A. (250mL)', 'Tubos de ensaio (20 un)'],
      status: 'Reprovada'
    },
    {
      id: 'SOL-2024-007',
      professor: 'Prof. Carlos Lima',
      disciplina: 'Físico-Química',
      data: '15/09/2024',
      turma: '2º Ano A',
      itens: ['Hidróxido de Sódio micropérolas (500g)', 'Fenolftaleína sol. 1% (100mL)', 'Bureta 50mL (5 un)'],
      status: 'Aprovada'
    },
    {
      id: 'SOL-2024-008',
      professor: 'Prof. João Pedro',
      disciplina: 'Bioquímica Aplicada',
      data: '14/09/2024',
      turma: '1º Ano C',
      itens: ['Sulfato de Cobre Penta-hidratado (250g)', 'Reagente de Benedict (500mL)'],
      status: 'Pendente'
    },
    {
      id: 'SOL-2024-004',
      professor: 'Prof. Maria Souza',
      disciplina: 'Química Geral',
      data: '12/09/2024',
      turma: '1º Ano A',
      itens: ['Nitrato de Prata P.A. (25g)', 'Cloreto de Sódio P.A. (1kg)', 'Béqueres 250mL (10 un)'],
      status: 'Aprovada'
    },
    {
      id: 'SOL-2024-001',
      professor: 'Prof. Maria Souza',
      disciplina: 'Química Geral',
      data: '08/09/2024',
      turma: '2º Ano B',
      itens: ['Álcool Etílico 96º GL (1000mL)', 'Placas de Petri de vidro (15 un)'],
      status: 'Aprovada'
    },
  ]);

  const produtos = [
    { cod: 'PRD-0102', nome: 'Ácido Clorídrico 37% P.A.', cas: '7647-01-0', cat: 'Ácidos', estoque: '1.2 L', min: '2.0 L', status: 'Baixo' },
    { cod: 'PRD-0108', nome: 'Ácido Sulfúrico 98% P.A.', cas: '7664-93-9', cat: 'Ácidos', estoque: '450 mL', min: '1.5 L', status: 'Crítico' },
    { cod: 'PRD-0215', nome: 'Hidróxido de Sódio P.A.', cas: '1310-73-2', cat: 'Bases', estoque: '3.5 kg', min: '1.0 kg', status: 'Normal' },
    { cod: 'PRD-0340', nome: 'Acetona P.A. Grau Reagente', cas: '67-64-1', cat: 'Solventes', estoque: '4.0 L', min: '2.0 L', status: 'Normal' },
    { cod: 'PRD-0412', nome: 'Permanganato de Potássio', cas: '7722-64-7', cat: 'Oxidantes', estoque: '180 g', min: '500 g', status: 'Baixo' },
    { cod: 'PRD-0520', nome: 'Nitrato de Prata P.A.', cas: '7761-88-8', cat: 'Corrosivos', estoque: '45 g', min: '100 g', status: 'Baixo' },
    { cod: 'PRD-0630', nome: 'Álcool Isopropílico 99.8%', cas: '67-63-0', cat: 'Solventes', estoque: '800 mL', min: '2.0 L', status: 'Baixo' },
  ];

  const menuItems = [
    { name: 'Dashboard', icon: Home },
    { name: 'Produtos', icon: FlaskConical },
    { name: 'Fornecedores', icon: Truck },
    { name: 'Solicitações', icon: FileText },
    { name: 'Compras', icon: ShoppingCart },
    { name: 'Estoque', icon: Package },
    { name: 'Relatórios', icon: BarChart3 },
    { name: 'Alertas', icon: AlertTriangle, badge: '15' },
  ];

  // Meses e coordenadas SVG calibradas com precisão
  const meses = [
    { mes: 'Jan', val: '15K', valorFull: 'R$ 15.200', x: 45, y: 145 },
    { mes: 'Fev', val: '25K', valorFull: 'R$ 24.800', x: 85, y: 115 },
    { mes: 'Mar', val: '30K', valorFull: 'R$ 30.150', x: 125, y: 90 },
    { mes: 'Abr', val: '28K', valorFull: 'R$ 28.400', x: 165, y: 98 },
    { mes: 'Mai', val: '20K', valorFull: 'R$ 20.900', x: 205, y: 125 },
    { mes: 'Jun', val: '35K', valorFull: 'R$ 35.600', x: 245, y: 60 },
    { mes: 'Jul', val: '40K', valorFull: 'R$ 39.800', x: 285, y: 40 },
    { mes: 'Ago', val: '34K', valorFull: 'R$ 34.200', x: 325, y: 65 },
    { mes: 'Set', val: '25K', valorFull: 'R$ 24.560', x: 365, y: 90 },
    { mes: 'Out', val: '31K', valorFull: 'R$ 31.000', x: 405, y: 78 },
    { mes: 'Nov', val: '33K', valorFull: 'R$ 33.400', x: 445, y: 65 },
    { mes: 'Dez', val: '36K', valorFull: 'R$ 36.100', x: 485, y: 58 },
  ];

  const mudarStatusSolicitacao = (id: string, novoStatus: 'Aprovada' | 'Reprovada' | 'Pendente') => {
    setSolicitacoes((prev) =>
      prev.map((item) => (item.id === id ? { ...item, status: novoStatus } : item))
    );
    if (solicitacaoModal && solicitacaoModal.id === id) {
      setSolicitacaoModal({ ...solicitacaoModal, status: novoStatus });
    }
  };

  const solicitacoesFiltradas = solicitacoes.filter((s) => {
    const matchBusca =
      s.id.toLowerCase().includes(buscaSolicitacao.toLowerCase()) ||
      s.professor.toLowerCase().includes(buscaSolicitacao.toLowerCase());
    const matchStatus = filtroStatus === 'Todos' || s.status === filtroStatus;
    return matchBusca && matchStatus;
  });

  return (
    <div className="w-full min-h-screen flex bg-[#F0F3F9] text-zinc-800 font-sans antialiased overflow-x-hidden">
      {/* ========================================================================= */}
      {/* 1. SIDEBAR LATERAL ESCURA DO FIGMA (w-56 para proporção harmoniosa)       */}
      {/* ========================================================================= */}
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-56 bg-black flex flex-col justify-between transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 ${
          sidebarMobileAberta ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div>
          {/* Logo Matéria Reativa com largura proporcional */}
          <div className="p-4 pb-3 flex items-center justify-between border-b border-zinc-900">
            <div
              className="w-full cursor-pointer transition hover:opacity-90 flex items-center justify-center py-1"
              onClick={() => onNavigate('index')}
              title="Voltar para a escolha de perfil"
            >
              <Logo width={150} variant="light" className="mx-auto" />
            </div>
            <button
              onClick={() => setSidebarMobileAberta(false)}
              className="lg:hidden text-zinc-400 hover:text-white p-1 rounded-md"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Itens de navegação com espaçamento confortável */}
          <nav className="mt-3 px-2.5 space-y-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              const isSelected = menuAtivo === item.name;
              return (
                <button
                  key={item.name}
                  onClick={() => {
                    setMenuAtivo(item.name);
                    setSidebarMobileAberta(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition cursor-pointer ${
                    isSelected
                      ? 'bg-zinc-800 text-white font-semibold'
                      : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isSelected ? 'text-[#2F80ED]' : 'text-zinc-400'}`} />
                    <span>{item.name}</span>
                  </div>
                  {item.badge && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Perfil no rodapé da Sidebar do Figma: Katia Eliana */}
        <div className="p-3 border-t border-zinc-900 relative bg-black">
          <div
            onClick={() => setMenuUsuarioAberto(!menuUsuarioAberto)}
            className="flex items-center justify-between p-1.5 rounded-lg hover:bg-zinc-900 cursor-pointer transition select-none"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold ring-1 ring-white/20 flex-shrink-0">
                <span>KE</span>
              </div>
              <div className="text-left overflow-hidden">
                <p className="text-xs font-semibold text-white leading-tight truncate">Katia Eliana</p>
                <span className="text-[10px] text-zinc-400 block truncate">Coordenadora</span>
              </div>
            </div>
            <MoreVertical className="w-4 h-4 text-zinc-400 hover:text-white transition flex-shrink-0" />
          </div>

          {menuUsuarioAberto && (
            <div className="absolute bottom-14 left-2 right-2 bg-zinc-900 border border-zinc-800 rounded-xl p-1.5 shadow-2xl z-50 animate-in fade-in zoom-in-95">
              <button
                onClick={() => onNavigate('index')}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-zinc-300 hover:bg-zinc-800 rounded-lg transition"
              >
                <User className="w-3.5 h-3.5 text-blue-400" />
                <span>Trocar Perfil</span>
              </button>
              <button
                onClick={() => onNavigate('login')}
                className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-red-400 hover:bg-red-950/40 rounded-lg transition"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sair da conta</span>
              </button>
            </div>
          )}
        </div>
      </aside>

      {sidebarMobileAberta && (
        <div
          onClick={() => setSidebarMobileAberta(false)}
          className="fixed inset-0 bg-black/60 z-30 lg:hidden backdrop-blur-xs"
        />
      )}

      {/* ========================================================================= */}
      {/* 2. ÁREA PRINCIPAL COM PROPORÇÕES REFINADAS E CONFORTÁVEIS                 */}
      {/* ========================================================================= */}
      <main className="flex-1 min-w-0 flex flex-col max-h-screen overflow-y-auto">
        {/* Barra superior de cabeçalho */}
        <header className="sticky top-0 z-20 bg-white/90 backdrop-blur-md border-b border-zinc-200/80 px-5 sm:px-7 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarMobileAberta(true)}
              className="lg:hidden p-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-700"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-base font-bold text-zinc-900 leading-tight">
                {menuAtivo === 'Dashboard' ? 'Painel de Controle' : menuAtivo}
              </h1>
              <p className="text-[11px] text-zinc-500 hidden sm:block">
                Laboratório de Química • Escola Estadual
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {/* Barra de busca global com atalho ⌘K */}
            <div className="relative hidden md:block">
              <button
                type="button"
                onClick={() => setSpotlightAberto(true)}
                className="w-52 lg:w-64 h-8 pl-8 pr-2.5 text-xs bg-zinc-100 hover:bg-zinc-200/70 rounded-lg border border-zinc-200/80 text-left text-zinc-500 flex items-center justify-between transition cursor-pointer group"
                title="Abrir busca global do sistema (Ctrl+K)"
              >
                <div className="flex items-center gap-2 truncate">
                  <Search className="w-3.5 h-3.5 text-zinc-400 group-hover:text-zinc-600 flex-shrink-0" />
                  <span className="truncate">Buscar no sistema...</span>
                </div>
                <kbd className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-mono text-zinc-400 bg-white border border-zinc-200 rounded shadow-2xs">
                  ⌘K
                </kbd>
              </button>
            </div>

            {/* Sino de Notificações */}
            <div className="relative">
              <button
                onClick={() => setNotificacoesAbertas(!notificacoesAbertas)}
                className="p-2 rounded-lg hover:bg-zinc-100 text-zinc-600 relative transition"
                title="Notificações"
              >
                <Bell className="w-4 h-4" />
                <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-red-500" />
              </button>

              {notificacoesAbertas && (
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-xl shadow-xl border border-zinc-200 p-3 z-50">
                  <div className="flex items-center justify-between pb-2 border-b border-zinc-100 text-xs font-bold text-zinc-800">
                    <span>Notificações</span>
                    <span className="text-[10px] text-blue-600 font-normal cursor-pointer">Marcar lidas</span>
                  </div>
                  <div className="py-2 text-[11px] text-zinc-600 space-y-2">
                    <p><strong>Estoque Baixo:</strong> Ácido Sulfúrico 98% atingiu nível crítico.</p>
                    <p><strong>Solicitação:</strong> Prof. João Pedro aguarda aprovação.</p>
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={() => setNovaSolicitacaoAberta(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#2F80ED] hover:bg-blue-600 text-white text-xs font-semibold shadow-xs transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Solicitação</span>
            </button>
          </div>
        </header>

        {/* Conteúdo com espaçamento e proporção ajustados */}
        <div className="p-4 sm:p-6 lg:p-7 space-y-5 max-w-7xl">
          {menuAtivo === 'Dashboard' && (
            <>
              {/* ================================================================= */}
              {/* 1. TOPO: 4 CARDS DE MÉTRICAS COM ALTURA E PROPORÇÃO CONFORTÁVEIS  */}
              {/*    (Design refinado, padding px-5 py-3.5, tipografia balanceada)  */}
              {/* ================================================================= */}
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
                {/* Card 1: Produtos */}
                <div
                  onClick={() => setMenuAtivo('Produtos')}
                  className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between hover:brightness-105 transition cursor-pointer min-h-[96px]"
                >
                  <div className="flex flex-col justify-center">
                    <span className="text-xs font-medium text-blue-100">Produtos</span>
                    <span className="text-2xl sm:text-[26px] font-bold tracking-tight text-white my-0.5 leading-none">
                      243
                    </span>
                    <span className="text-[11px] text-blue-200/90 font-normal">Total cadastrado</span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
                    <FlaskConical className="w-5 h-5" />
                  </div>
                </div>

                {/* Card 2: Solicitações */}
                <div
                  onClick={() => setMenuAtivo('Solicitações')}
                  className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between hover:brightness-105 transition cursor-pointer min-h-[96px]"
                >
                  <div className="flex flex-col justify-center">
                    <span className="text-xs font-medium text-blue-100">Solicitações</span>
                    <span className="text-2xl sm:text-[26px] font-bold tracking-tight text-white my-0.5 leading-none">
                      8
                    </span>
                    <span className="text-[11px] text-blue-200/90 font-normal">Pendentes</span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                </div>

                {/* Card 3: Compras */}
                <div
                  onClick={() => setMenuAtivo('Compras')}
                  className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between hover:brightness-105 transition cursor-pointer min-h-[96px]"
                >
                  <div className="flex flex-col justify-center">
                    <span className="text-xs font-medium text-blue-100">Compras</span>
                    <span className="text-2xl sm:text-[26px] font-bold tracking-tight text-white my-0.5 leading-none">
                      R$24.560
                    </span>
                    <span className="text-[11px] text-blue-200/90 font-normal">Mês atual</span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
                    <ShoppingCart className="w-5 h-5" />
                  </div>
                </div>

                {/* Card 4: Estoque Baixo */}
                <div
                  onClick={() => setMenuAtivo('Alertas')}
                  className="bg-[#2F80ED] text-white rounded-xl px-5 py-4 shadow-sm shadow-blue-500/10 flex items-center justify-between hover:brightness-105 transition cursor-pointer min-h-[96px]"
                >
                  <div className="flex flex-col justify-center">
                    <span className="text-xs font-medium text-blue-100">Estoque baixo</span>
                    <span className="text-2xl sm:text-[26px] font-bold tracking-tight text-white my-0.5 leading-none">
                      15
                    </span>
                    <span className="text-[11px] text-blue-200/90 font-normal">Produtos</span>
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-white flex-shrink-0">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* ================================================================= */}
              {/* 1.1 BARRA DE TELEMETRIA OPERACIONAL DO LABORATÓRIO (CIENTÍFICA)    */}
              {/* ================================================================= */}
              <div className="bg-white rounded-xl p-3 shadow-xs border border-zinc-200/70 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="font-bold text-zinc-800 text-[11px] tracking-wide">
                    STATUS OPERACIONAL DO LABORATÓRIO:
                  </span>
                  <span className="text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    100% Em Conformidade
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-[11px]">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-50 border border-zinc-200 text-zinc-700">
                    <Activity className="w-3.5 h-3.5 text-[#2F80ED]" />
                    <span>Capela 01: <strong>0.54 m/s</strong> (Nominal)</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-50 border border-zinc-200 text-zinc-700">
                    <Thermometer className="w-3.5 h-3.5 text-blue-600" />
                    <span>Armário Inflamáveis: <strong>19.4 °C</strong></span>
                  </div>
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-zinc-50 border border-zinc-200 text-zinc-700">
                    <ShieldCheck className="w-3.5 h-3.5 text-purple-600" />
                    <span>SIPROQUIM / PF: <strong>Homologado</strong></span>
                  </div>
                </div>
              </div>

              {/* ================================================================= */}
              {/* 2. LINHA DO MEIO: DOIS GRÁFICOS COM ALTURAS ALINHADAS E PROPORÇÃO */}
              {/* ================================================================= */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-stretch">
                {/* Gráfico de Compras do Mês (7 colunas) */}
                <div className="lg:col-span-7 xl:col-span-8 bg-white rounded-xl p-5 shadow-xs border border-zinc-200/70 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h3 className="text-sm font-bold text-zinc-900">Compras do Mês</h3>
                      <p className="text-[11px] text-zinc-400">
                        {pontoSelecionado ? (
                          <span className="text-[#2F80ED] font-semibold">
                            {pontoSelecionado.mes}: {pontoSelecionado.valor}
                          </span>
                        ) : (
                          'Valores consolidados por mês'
                        )}
                      </p>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-zinc-100 text-zinc-600 font-medium">
                      Ano 2024
                    </span>
                  </div>

                  <div className="w-full overflow-x-auto">
                    <div className="min-w-[480px]">
                      <svg viewBox="0 0 540 160" className="w-full h-38">
                        {/* Linhas de grade e valores do eixo Y */}
                        {[
                          { val: '40K', y: 20 },
                          { val: '35K', y: 50 },
                          { val: '30K', y: 80 },
                          { val: '25K', y: 110 },
                          { val: '15K', y: 140 },
                        ].map((line, idx) => (
                          <g key={idx}>
                            <text x="2" y={line.y + 3.5} fill="#9CA3AF" fontSize="9" fontFamily="sans-serif">
                              {line.val}
                            </text>
                            <line
                              x1="30"
                              y1={line.y}
                              x2="520"
                              y2={line.y}
                              stroke="#F3F4F6"
                              strokeWidth="1"
                            />
                          </g>
                        ))}

                        {/* Definição de gradiente suave para a área do gráfico */}
                        <defs>
                          <linearGradient id="consumoGradiente" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#2F80ED" stopOpacity="0.22" />
                            <stop offset="100%" stopColor="#2F80ED" stopOpacity="0.0" />
                          </linearGradient>
                        </defs>

                        {/* Área preenchida sob a curva */}
                        <path
                          d="M 45 140 L 85 110 L 125 85 L 165 92 L 205 120 L 245 55 L 285 35 L 325 60 L 365 85 L 405 72 L 445 60 L 485 52 L 485 140 L 45 140 Z"
                          fill="url(#consumoGradiente)"
                        />

                        {/* Linha azul do gráfico */}
                        <path
                          d="M 45 140 L 85 110 L 125 85 L 165 92 L 205 120 L 245 55 L 285 35 L 325 60 L 365 85 L 405 72 L 445 60 L 485 52"
                          fill="none"
                          stroke="#2F80ED"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />

                        {/* Pontos da linha */}
                        {meses.map((p, i) => (
                          <circle
                            key={i}
                            cx={p.x}
                            cy={p.y - 5}
                            r={pontoSelecionado?.mes === p.mes ? '5' : '3.2'}
                            fill="#2F80ED"
                            stroke="#FFFFFF"
                            strokeWidth="1.5"
                            className="cursor-pointer hover:r-5 transition-all"
                            onMouseEnter={() => setPontoSelecionado({ mes: p.mes, valor: p.valorFull })}
                            onMouseLeave={() => setPontoSelecionado(null)}
                          />
                        ))}
                      </svg>

                      {/* Eixo X com os meses */}
                      <div className="flex justify-between pl-8 pr-6 text-[10px] text-zinc-400 font-medium">
                        {meses.map((m) => (
                          <span
                            key={m.mes}
                            className={`cursor-pointer hover:text-blue-600 transition ${
                              pontoSelecionado?.mes === m.mes ? 'text-blue-600 font-bold' : ''
                            }`}
                            onClick={() => setPontoSelecionado({ mes: m.mes, valor: m.valorFull })}
                          >
                            {m.mes}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Gráfico de Categorias em Rosca (5 colunas) */}
                <div className="lg:col-span-5 xl:col-span-4 bg-white rounded-xl p-5 shadow-xs border border-zinc-200/70 flex flex-col justify-between">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-sm font-bold text-zinc-900">Categorias</h3>
                    {categoriaHover ? (
                      <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                        {categoriaHover}
                      </span>
                    ) : (
                      <span className="text-[10px] text-zinc-400">Total: 243 itens</span>
                    )}
                  </div>

                  <div className="flex items-center justify-center gap-4 py-1 flex-1">
                    {/* Rosca SVG Proporcional */}
                    <div className="relative w-32 h-32 flex-shrink-0">
                      <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
                        {/* Segmentos proporcionais */}
                        <circle
                          cx="50"
                          cy="50"
                          r="36"
                          fill="transparent"
                          stroke="#582be8"
                          strokeWidth="16"
                          strokeDasharray="75 226"
                          strokeDashoffset="0"
                          className="hover:opacity-85 transition cursor-pointer"
                          onMouseEnter={() => setCategoriaHover('Ácidos: 33%')}
                          onMouseLeave={() => setCategoriaHover(null)}
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="36"
                          fill="transparent"
                          stroke="#2f80ed"
                          strokeWidth="16"
                          strokeDasharray="50 226"
                          strokeDashoffset="-75"
                          className="hover:opacity-85 transition cursor-pointer"
                          onMouseEnter={() => setCategoriaHover('Bases: 22%')}
                          onMouseLeave={() => setCategoriaHover(null)}
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="36"
                          fill="transparent"
                          stroke="#00b4d8"
                          strokeWidth="16"
                          strokeDasharray="40 226"
                          strokeDashoffset="-125"
                          className="hover:opacity-85 transition cursor-pointer"
                          onMouseEnter={() => setCategoriaHover('Solventes: 18%')}
                          onMouseLeave={() => setCategoriaHover(null)}
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="36"
                          fill="transparent"
                          stroke="#8b5cf6"
                          strokeWidth="16"
                          strokeDasharray="35 226"
                          strokeDashoffset="-165"
                          className="hover:opacity-85 transition cursor-pointer"
                          onMouseEnter={() => setCategoriaHover('Oxidantes: 15%')}
                          onMouseLeave={() => setCategoriaHover(null)}
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="36"
                          fill="transparent"
                          stroke="#a78bfa"
                          strokeWidth="16"
                          strokeDasharray="18 226"
                          strokeDashoffset="-200"
                          className="hover:opacity-85 transition cursor-pointer"
                          onMouseEnter={() => setCategoriaHover('Corrosivos: 8%')}
                          onMouseLeave={() => setCategoriaHover(null)}
                        />
                        <circle
                          cx="50"
                          cy="50"
                          r="36"
                          fill="transparent"
                          stroke="#cbd5e1"
                          strokeWidth="16"
                          strokeDasharray="8 226"
                          strokeDashoffset="-218"
                          className="hover:opacity-85 transition cursor-pointer"
                          onMouseEnter={() => setCategoriaHover('Outros: 4%')}
                          onMouseLeave={() => setCategoriaHover(null)}
                        />
                      </svg>
                    </div>

                    {/* Legenda das Categorias */}
                    <div className="space-y-1 text-[11px] text-zinc-600 font-medium">
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-zinc-900" onMouseEnter={() => setCategoriaHover('Ácidos: 33%')} onMouseLeave={() => setCategoriaHover(null)}>
                        <span className="w-2.5 h-2.5 rounded-xs bg-[#582be8] flex-shrink-0" />
                        <span>Ácidos (33%)</span>
                      </div>
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-zinc-900" onMouseEnter={() => setCategoriaHover('Bases: 22%')} onMouseLeave={() => setCategoriaHover(null)}>
                        <span className="w-2.5 h-2.5 rounded-xs bg-[#2f80ed] flex-shrink-0" />
                        <span>Bases (22%)</span>
                      </div>
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-zinc-900" onMouseEnter={() => setCategoriaHover('Solventes: 18%')} onMouseLeave={() => setCategoriaHover(null)}>
                        <span className="w-2.5 h-2.5 rounded-xs bg-[#00b4d8] flex-shrink-0" />
                        <span>Solventes (18%)</span>
                      </div>
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-zinc-900" onMouseEnter={() => setCategoriaHover('Oxidantes: 15%')} onMouseLeave={() => setCategoriaHover(null)}>
                        <span className="w-2.5 h-2.5 rounded-xs bg-[#8b5cf6] flex-shrink-0" />
                        <span>Oxidantes (15%)</span>
                      </div>
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-zinc-900" onMouseEnter={() => setCategoriaHover('Corrosivos: 8%')} onMouseLeave={() => setCategoriaHover(null)}>
                        <span className="w-2.5 h-2.5 rounded-xs bg-[#a78bfa] flex-shrink-0" />
                        <span>Corrosivos (8%)</span>
                      </div>
                      <div className="flex items-center gap-1.5 cursor-pointer hover:text-zinc-900" onMouseEnter={() => setCategoriaHover('Outros: 4%')} onMouseLeave={() => setCategoriaHover(null)}>
                        <span className="w-2.5 h-2.5 rounded-xs bg-[#cbd5e1] flex-shrink-0" />
                        <span>Outros (4%)</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right text-[10px] text-zinc-400 pt-1">Distribuição: 100%</div>
                </div>
              </div>

              {/* ================================================================= */}
              {/* 3. PARTE INFERIOR: TABELA COM PROPORÇÃO HARMONIOSA               */}
              {/* ================================================================= */}
              <div className="bg-white rounded-xl p-5 shadow-xs border border-zinc-200/70 max-w-3xl">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-bold text-zinc-900">Últimas Solicitações</h3>
                  <select
                    value={filtroStatus}
                    onChange={(e) => setFiltroStatus(e.target.value as any)}
                    className="text-xs bg-zinc-50 border border-zinc-200 rounded-md px-2 py-1 text-zinc-600 focus:outline-none"
                  >
                    <option value="Todos">Todas</option>
                    <option value="Aprovada">Aprovadas</option>
                    <option value="Pendente">Pendentes</option>
                    <option value="Reprovada">Reprovadas</option>
                  </select>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="text-[11px] text-zinc-400 border-b border-zinc-100 font-medium">
                        <th className="pb-2">Código</th>
                        <th className="pb-2">Professor</th>
                        <th className="pb-2">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-50 text-[11px]">
                      {solicitacoesFiltradas.map((s, index) => {
                        let corBadge = 'bg-amber-50 text-amber-700 border-amber-200';
                        if (s.status === 'Aprovada') {
                          corBadge = 'bg-emerald-50 text-emerald-700 border-emerald-200';
                        } else if (s.status === 'Reprovada') {
                          corBadge = 'bg-rose-50 text-rose-700 border-rose-200';
                        }

                        return (
                          <tr
                            key={index}
                            onClick={() => setSolicitacaoModal(s)}
                            className="hover:bg-blue-50/30 transition cursor-pointer"
                          >
                            <td className="py-2.5 font-semibold text-[#2F80ED]">{s.id}</td>
                            <td className="py-2.5 text-zinc-700 font-medium">{s.professor}</td>
                            <td className="py-2.5">
                              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-semibold border ${corBadge}`}>
                                {s.status}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* ================================================================= */}
          {/* MÓDULOS OPERACIONAIS COMPLETOS E FIÉIS AO FIGMA                   */}
          {/* ================================================================= */}
          {menuAtivo === 'Produtos' && (
            <ProdutosView
              produtos={produtosQuimicos}
              onAddProduto={handleAddProduto}
              onUpdateProduto={handleUpdateProduto}
              onDeleteProduto={handleDeleteProduto}
            />
          )}

          {menuAtivo === 'Fornecedores' && (
            <FornecedoresView
              fornecedores={fornecedores}
              onAddFornecedor={handleAddFornecedor}
              onUpdateFornecedor={handleUpdateFornecedor}
              onDeleteFornecedor={handleDeleteFornecedor}
            />
          )}

          {menuAtivo === 'Solicitações' && (
            <SolicitacoesView
              solicitacoes={solicitacoesLab}
              onAddSolicitacao={handleAddSolicitacao}
              onUpdateSolicitacaoStatus={handleUpdateSolicitacaoStatus}
              onDeleteSolicitacao={handleDeleteSolicitacao}
              produtosDisponiveis={nomesProdutosDisponiveis}
            />
          )}

          {menuAtivo === 'Compras' && (
            <ComprasView
              compras={compras}
              fornecedores={fornecedores}
              produtosDisponiveis={nomesProdutosDisponiveis}
              onAddCompra={handleAddCompra}
              onUpdateCompraStatus={handleUpdateCompraStatus}
              onDeleteCompra={handleDeleteCompra}
            />
          )}

          {menuAtivo === 'Estoque' && (
            <EstoqueView
              estoque={estoque}
              produtosQuimicos={produtosQuimicos}
              onAddEstoque={handleAddEstoque}
              onUpdateEstoque={handleUpdateEstoque}
              onDeleteEstoque={handleDeleteEstoque}
              onUpdateQuantidade={handleUpdateEstoqueQtd}
              onAddMovimentacao={handleAddMovimentacao}
            />
          )}

          {menuAtivo === 'Relatórios' && <RelatoriosView />}

          {menuAtivo === 'Alertas' && (
            <AlertasView onNavigateToCompras={() => setMenuAtivo('Compras')} />
          )}
        </div>
      </main>

      {/* Modal de Detalhes da Solicitação */}
      {solicitacaoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3.5 bg-zinc-900 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono text-blue-400">{solicitacaoModal.id}</span>
                <h3 className="text-sm font-bold">Solicitação de Aula Prática</h3>
              </div>
              <button onClick={() => setSolicitacaoModal(null)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-2 pb-2 border-b border-zinc-100">
                <div>
                  <span className="text-zinc-400 block text-[10px]">Docente:</span>
                  <strong className="text-zinc-800">{solicitacaoModal.professor}</strong>
                </div>
                <div>
                  <span className="text-zinc-400 block text-[10px]">Data:</span>
                  <strong className="text-zinc-800">{solicitacaoModal.data}</strong>
                </div>
                <div>
                  <span className="text-zinc-400 block text-[10px]">Disciplina:</span>
                  <span className="text-zinc-700">{solicitacaoModal.disciplina}</span>
                </div>
                <div>
                  <span className="text-zinc-400 block text-[10px]">Turma:</span>
                  <span className="text-zinc-700">{solicitacaoModal.turma}</span>
                </div>
              </div>

              <div>
                <p className="font-semibold text-zinc-800 mb-1">Reagentes Requisitados:</p>
                <ul className="space-y-1 bg-zinc-50 p-2.5 rounded-lg border border-zinc-100 text-[11px] text-zinc-700">
                  {solicitacaoModal.itens.map((item, idx) => (
                    <li key={idx} className="flex items-center gap-1.5">
                      <span className="w-1 h-1 rounded-full bg-blue-500" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-zinc-500">Status atual:</span>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-semibold border bg-zinc-50">
                  {solicitacaoModal.status}
                </span>
              </div>
            </div>

            <div className="px-5 py-3 bg-zinc-50 border-t border-zinc-100 flex items-center justify-between">
              <button
                onClick={() => setSolicitacaoModal(null)}
                className="px-3 py-1.5 text-xs text-zinc-600 hover:bg-zinc-200 rounded-md"
              >
                Fechar
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => mudarStatusSolicitacao(solicitacaoModal.id, 'Reprovada')}
                  className="px-3 py-1.5 rounded-md bg-rose-50 text-rose-700 text-xs font-semibold hover:bg-rose-100"
                >
                  Reprovar
                </button>
                <button
                  onClick={() => mudarStatusSolicitacao(solicitacaoModal.id, 'Aprovada')}
                  className="px-3.5 py-1.5 rounded-md bg-[#2F80ED] text-white text-xs font-semibold hover:bg-blue-600"
                >
                  Aprovar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Nova Solicitação */}
      {novaSolicitacaoAberta && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95">
            <div className="px-5 py-3 bg-zinc-900 text-white flex items-center justify-between">
              <h3 className="text-xs font-bold">Nova Solicitação de Reagentes</h3>
              <button onClick={() => setNovaSolicitacaoAberta(false)} className="text-zinc-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                const novoItem: SolicitacaoItem = {
                  id: `SOL-2024-00${solicitacoes.length + 1}`,
                  professor: (formData.get('professor') as string) || 'Prof. Katia Eliana',
                  disciplina: (formData.get('disciplina') as string) || 'Química Geral',
                  data: new Date().toLocaleDateString('pt-BR'),
                  turma: (formData.get('turma') as string) || '3º Ano',
                  itens: [(formData.get('itens') as string) || 'Reagentes diversos'],
                  status: 'Pendente'
                };
                setSolicitacoes([novoItem, ...solicitacoes]);
                setNovaSolicitacaoAberta(false);
              }}
              className="p-5 space-y-2.5 text-xs"
            >
              <div>
                <label className="block text-zinc-600 mb-0.5">Professor</label>
                <input type="text" name="professor" defaultValue="Prof. Katia Eliana" required className="w-full h-8 px-2.5 border border-zinc-300 rounded-md text-xs" />
              </div>
              <div>
                <label className="block text-zinc-600 mb-0.5">Disciplina</label>
                <input type="text" name="disciplina" placeholder="Ex: Físico-Química" required className="w-full h-8 px-2.5 border border-zinc-300 rounded-md text-xs" />
              </div>
              <div>
                <label className="block text-zinc-600 mb-0.5">Reagentes</label>
                <textarea name="itens" rows={2} placeholder="Ex: Hidróxido de Sódio, Fenolftaleína" required className="w-full p-2 border border-zinc-300 rounded-md text-xs" />
              </div>
              <div className="pt-2 flex justify-end gap-2">
                <button type="button" onClick={() => setNovaSolicitacaoAberta(false)} className="px-3 py-1.5 text-xs text-zinc-600">Cancelar</button>
                <button type="submit" className="px-3.5 py-1.5 rounded-md bg-[#2F80ED] text-white text-xs font-semibold">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* ========================================================================= */}
      {/* MODAL SPOTLIGHT SEARCH / COMMAND PALETTE (CTRL+K)                         */}
      {/* ========================================================================= */}
      {spotlightAberto && (
        <div
          onClick={() => setSpotlightAberto(false)}
          className="fixed inset-0 z-50 flex items-start justify-center bg-black/60 backdrop-blur-xs p-4 pt-16 sm:pt-24"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in zoom-in-95 flex flex-col max-h-[80vh]"
          >
            {/* Campo de Busca Spotlight */}
            <div className="flex items-center px-4 py-3.5 border-b border-zinc-200 gap-3 bg-zinc-50/70">
              <Search className="w-5 h-5 text-blue-600 flex-shrink-0" />
              <input
                autoFocus
                type="text"
                value={buscaSpotlight}
                onChange={(e) => setBuscaSpotlight(e.target.value)}
                placeholder="Pesquise reagentes, CAS, lotes, fornecedores ou atalhos..."
                className="w-full bg-transparent text-sm text-zinc-900 placeholder:text-zinc-400 focus:outline-none"
              />
              {buscaSpotlight && (
                <button
                  onClick={() => setBuscaSpotlight('')}
                  className="p-1 rounded-md text-zinc-400 hover:text-zinc-600 text-xs"
                >
                  Limpar
                </button>
              )}
              <kbd className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-mono text-zinc-400 bg-white border border-zinc-200 rounded">
                ESC
              </kbd>
            </div>

            {/* Resultados em Lista Segmentada */}
            <div className="p-3 overflow-y-auto space-y-3 flex-1 text-xs">
              {/* Se não digitou nada, mostra atalhos de navegação direta */}
              {!buscaSpotlight.trim() && (
                <div>
                  <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider px-2 block mb-1.5">
                    Navegação Rápida
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {menuItems.map((it) => {
                      const Icon = it.icon;
                      return (
                        <button
                          key={it.name}
                          onClick={() => {
                            setMenuAtivo(it.name);
                            setSpotlightAberto(false);
                          }}
                          className="flex items-center justify-between p-2.5 rounded-xl hover:bg-blue-50/50 hover:text-blue-700 text-zinc-700 transition text-left cursor-pointer group"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className="w-7 h-7 rounded-lg bg-zinc-100 group-hover:bg-blue-100 text-zinc-600 group-hover:text-blue-600 flex items-center justify-center transition">
                              <Icon className="w-4 h-4" />
                            </div>
                            <span className="font-semibold">{it.name}</span>
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 text-zinc-300 group-hover:text-blue-600 transition" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Se digitou algo, filtra em tempo real todos os módulos */}
              {buscaSpotlight.trim() && (
                <>
                  {/* Reagentes Químicos */}
                  {produtosQuimicos.filter(
                    (p) =>
                      p.nome.toLowerCase().includes(buscaSpotlight.toLowerCase()) ||
                      p.cas.toLowerCase().includes(buscaSpotlight.toLowerCase()) ||
                      (p.formulaQuimica && p.formulaQuimica.toLowerCase().includes(buscaSpotlight.toLowerCase()))
                  ).length > 0 && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider px-2 block mb-1">
                        Reagentes Químicos (Catálogo)
                      </span>
                      <div className="space-y-1">
                        {produtosQuimicos
                          .filter(
                            (p) =>
                              p.nome.toLowerCase().includes(buscaSpotlight.toLowerCase()) ||
                              p.cas.toLowerCase().includes(buscaSpotlight.toLowerCase()) ||
                              (p.formulaQuimica && p.formulaQuimica.toLowerCase().includes(buscaSpotlight.toLowerCase()))
                          )
                          .slice(0, 4)
                          .map((prod) => (
                            <button
                              key={prod.id}
                              onClick={() => {
                                setMenuAtivo('Produtos');
                                setSpotlightAberto(false);
                              }}
                              className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-blue-50/60 transition text-left cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <FlaskConical className="w-4 h-4 text-blue-600" />
                                <div>
                                  <strong className="text-zinc-900 block">{prod.nome}</strong>
                                  <span className="text-zinc-500 font-mono text-[10px]">
                                    CAS: {prod.cas} {prod.formulaQuimica && `· ${prod.formulaQuimica}`}
                                  </span>
                                </div>
                              </div>
                              <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                                {prod.estoqueAtual} {prod.unidade}
                              </span>
                            </button>
                          ))}
                      </div>
                    </div>
                  )}

                  {/* Lotes do Estoque */}
                  {estoque.filter(
                    (e) =>
                      e.produto.toLowerCase().includes(buscaSpotlight.toLowerCase()) ||
                      e.lote.toLowerCase().includes(buscaSpotlight.toLowerCase())
                  ).length > 0 && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider px-2 block mb-1">
                        Lotes no Estoque Físico
                      </span>
                      <div className="space-y-1">
                        {estoque
                          .filter(
                            (e) =>
                              e.produto.toLowerCase().includes(buscaSpotlight.toLowerCase()) ||
                              e.lote.toLowerCase().includes(buscaSpotlight.toLowerCase())
                          )
                          .slice(0, 3)
                          .map((item) => (
                            <button
                              key={item.id}
                              onClick={() => {
                                setMenuAtivo('Estoque');
                                setSpotlightAberto(false);
                              }}
                              className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-emerald-50/60 transition text-left cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Package className="w-4 h-4 text-emerald-600" />
                                <div>
                                  <strong className="text-zinc-900 block">{item.produto}</strong>
                                  <span className="text-zinc-500 font-mono text-[10px]">
                                    Lote: {item.lote} · Val: {item.validade}
                                  </span>
                                </div>
                              </div>
                              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                                Saldo: {item.quantidadeAtual} {item.unidade}
                              </span>
                            </button>
                          ))}
                      </div>
                    </div>
                  )}

                  {/* Fornecedores */}
                  {fornecedores.filter(
                    (f) =>
                      f.razaoSocial.toLowerCase().includes(buscaSpotlight.toLowerCase()) ||
                      f.cnpj.includes(buscaSpotlight)
                  ).length > 0 && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider px-2 block mb-1">
                        Fornecedores Homologados
                      </span>
                      <div className="space-y-1">
                        {fornecedores
                          .filter(
                            (f) =>
                              f.razaoSocial.toLowerCase().includes(buscaSpotlight.toLowerCase()) ||
                              f.cnpj.includes(buscaSpotlight)
                          )
                          .slice(0, 2)
                          .map((forn) => (
                            <button
                              key={forn.id}
                              onClick={() => {
                                setMenuAtivo('Fornecedores');
                                setSpotlightAberto(false);
                              }}
                              className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-purple-50/60 transition text-left cursor-pointer"
                            >
                              <div className="flex items-center gap-2">
                                <Truck className="w-4 h-4 text-purple-600" />
                                <div>
                                  <strong className="text-zinc-900 block">{forn.razaoSocial}</strong>
                                  <span className="text-zinc-500 font-mono text-[10px]">CNPJ: {forn.cnpj}</span>
                                </div>
                              </div>
                              <span className="text-[10px] text-zinc-500">{forn.contato}</span>
                            </button>
                          ))}
                      </div>
                    </div>
                  )}

                  {/* Sem resultados */}
                  {produtosQuimicos.filter((p) => p.nome.toLowerCase().includes(buscaSpotlight.toLowerCase())).length === 0 &&
                    estoque.filter((e) => e.produto.toLowerCase().includes(buscaSpotlight.toLowerCase())).length === 0 &&
                    fornecedores.filter((f) => f.razaoSocial.toLowerCase().includes(buscaSpotlight.toLowerCase())).length === 0 && (
                      <div className="py-8 text-center text-zinc-400">
                        <p>Nenhum resultado para "{buscaSpotlight}".</p>
                        <p className="text-[11px] mt-1 text-zinc-500">Tente buscar pelo nome do reagente, fórmula ou número CAS.</p>
                      </div>
                    )}
                </>
              )}
            </div>

            {/* Rodapé do Spotlight */}
            <div className="px-4 py-2 bg-zinc-50 border-t border-zinc-200 flex items-center justify-between text-[11px] text-zinc-400">
              <span>Use <strong>Enter</strong> para selecionar ou <strong>Esc</strong> para sair</span>
              <span className="font-semibold text-zinc-600">Matéria Reativa OS</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
