import React, { useState, useEffect } from 'react';
import { Logo } from '../components/Logo';
import { WaveDna } from '../components/WaveDna';
import { Mail, EyeOff, Eye, ArrowLeft, Loader2, Sparkles } from 'lucide-react';

interface LoginScreenProps {
  userType: 'aluno' | 'professor';
  onNavigate: (screen: 'index' | 'login' | 'cadastro' | 'esqueceu-senha' | 'dashboard') => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ userType, onNavigate }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [lembrar, setLembrar] = useState(true);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    const emailSalvo = localStorage.getItem('materia_reativa_email');
    if (emailSalvo) {
      setEmail(emailSalvo);
    } else {
      if (userType === 'professor') {
        setEmail('katia.eliana@quimica.edu.br');
        setSenha('lab2024');
      } else {
        setEmail('aluno.laboratorio@escola.com');
        setSenha('aluno123');
      }
    }
  }, [userType]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErro(null);

    if (!email || !senha) {
      setErro('Por favor, preencha todos os campos.');
      return;
    }

    setCarregando(true);

    if (lembrar) {
      localStorage.setItem('materia_reativa_email', email);
    } else {
      localStorage.removeItem('materia_reativa_email');
    }

    setTimeout(() => {
      setCarregando(false);
      onNavigate('dashboard');
    }, 400);
  };

  const preencherDemo = (tipo: 'prof' | 'aluno') => {
    if (tipo === 'prof') {
      setEmail('katia.eliana@quimica.edu.br');
      setSenha('lab2024');
    } else {
      setEmail('lucas.silva@escola.edu.br');
      setSenha('quimica2024');
    }
  };

  return (
    <div className="w-full min-h-screen flex flex-col lg:flex-row bg-white overflow-x-hidden font-sans">
      {/* Botão de retorno e troca de perfil */}
      <button
        type="button"
        onClick={() => onNavigate('index')}
        className="absolute top-4 left-4 z-30 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold shadow-xs transition active:scale-95"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>Perfil: {userType === 'aluno' ? 'Aluno' : 'Professor(a)'}</span>
      </button>

      {/* LADO ESQUERDO: Formulário com Proporções Harmônicas do Figma */}
      <div className="w-full lg:w-1/2 min-h-screen flex items-center justify-center p-6 sm:p-10 lg:p-12 z-20">
        <div className="w-full max-w-[340px] flex flex-col items-center">
          {/* Logo Matéria Reativa */}
          <div
            className="mb-6 w-full flex items-center justify-center cursor-pointer transition hover:opacity-90 text-center"
            onClick={() => onNavigate('index')}
            title="Voltar ao início"
          >
            <Logo width={210} variant="dark" className="mx-auto" />
          </div>

          <form onSubmit={handleSubmit} className="w-full space-y-3.5">
            {erro && (
              <div className="p-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg text-center">
                {erro}
              </div>
            )}

            {/* Campo E-mail */}
            <div className="space-y-1">
              <label htmlFor="input-email" className="block text-xs font-semibold text-zinc-800">
                E-mail
              </label>
              <div className="relative">
                <input
                  id="input-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="exemplo@escola.com"
                  className="w-full h-10 px-3.5 pr-10 text-sm text-zinc-800 rounded-lg border border-zinc-300 focus:outline-none focus:border-[#2F80ED] focus:ring-1 focus:ring-[#2F80ED] transition shadow-2xs placeholder:text-zinc-400"
                />
                <Mail className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400 pointer-events-none" />
              </div>
            </div>

            {/* Campo Senha */}
            <div className="space-y-1">
              <label htmlFor="input-senha" className="block text-xs font-semibold text-zinc-800">
                Senha
              </label>
              <div className="relative">
                <input
                  id="input-senha"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={senha}
                  onChange={(e) => setSenha(e.target.value)}
                  placeholder="••••••••"
                  className="w-full h-10 px-3.5 pr-10 text-sm text-zinc-800 rounded-lg border border-zinc-300 focus:outline-none focus:border-[#2F80ED] focus:ring-1 focus:ring-[#2F80ED] transition shadow-2xs placeholder:text-zinc-400"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 transition p-0.5"
                  title={showPassword ? 'Ocultar senha' : 'Ver senha'}
                >
                  {showPassword ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Opções: Lembrar acesso e Esqueceu senha */}
            <div className="flex items-center justify-between pt-0.5 text-xs">
              <label className="flex items-center gap-1.5 cursor-pointer select-none text-zinc-700">
                <input
                  type="checkbox"
                  checked={lembrar}
                  onChange={(e) => setLembrar(e.target.checked)}
                  className="w-3.5 h-3.5 rounded border-zinc-300 text-[#2F80ED] focus:ring-[#2F80ED] cursor-pointer"
                />
                <span className="text-[11px] font-medium">Lembrar acesso</span>
              </label>

              <button
                type="button"
                onClick={() => onNavigate('esqueceu-senha')}
                className="text-[11px] text-[#2F80ED] hover:text-blue-700 hover:underline transition font-medium"
              >
                Esqueceu sua senha?
              </button>
            </div>

            {/* Botão Entrar Azul Vibrante do Figma (#2F80ED) */}
            <div className="pt-1.5">
              <button
                type="submit"
                disabled={carregando}
                className="w-full h-10 rounded-lg bg-[#2F80ED] hover:bg-[#256fd0] active:scale-[0.99] text-white text-sm font-semibold tracking-wide shadow-sm shadow-blue-500/20 transition cursor-pointer flex items-center justify-center gap-2"
              >
                {carregando ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Acessando...</span>
                  </>
                ) : (
                  <span>Entrar</span>
                )}
              </button>
            </div>

            {/* Link Cadastre-se */}
            <div className="text-center pt-0.5">
              <button
                type="button"
                onClick={() => onNavigate('cadastro')}
                className="text-xs text-[#2F80ED] hover:text-blue-700 hover:underline font-medium transition"
              >
                cadastre-se
              </button>
            </div>

            {/* Preenchimento de Demonstração */}
            <div className="pt-2 border-t border-zinc-100 flex items-center justify-center gap-1.5">
              <span className="text-[10px] text-zinc-400 flex items-center gap-1">
                <Sparkles className="w-2.5 h-2.5 text-amber-500" />
                Demo:
              </span>
              <button
                type="button"
                onClick={() => preencherDemo('prof')}
                className="text-[10px] text-zinc-600 bg-zinc-100 hover:bg-zinc-200 px-2 py-0.5 rounded transition font-medium"
              >
                Katia Eliana
              </button>
              <button
                type="button"
                onClick={() => preencherDemo('aluno')}
                className="text-[10px] text-zinc-600 bg-zinc-100 hover:bg-zinc-200 px-2 py-0.5 rounded transition font-medium"
              >
                Aluno
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* LADO DIREITO: Ilustração de DNA com Curva Orgânica */}
      <div className="hidden lg:block lg:w-1/2 min-h-screen">
        <WaveDna dnaPosition="right" />
      </div>
    </div>
  );
};
